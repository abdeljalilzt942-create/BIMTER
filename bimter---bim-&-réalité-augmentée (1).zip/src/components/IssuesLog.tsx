import React, { useState } from 'react';
import { SiteIssue, SystemType } from '../types';
import { motion, AnimatePresence } from 'motion/react';
import {
  Search,
  Filter,
  AlertTriangle,
  Clock,
  Trash2,
  User,
  Calendar,
  MapPin,
  AlertCircle,
  CheckCircle2,
  ChevronRight,
  HelpCircle,
  Inbox,
  Send,
} from 'lucide-react';

interface IssuesLogProps {
  issues: SiteIssue[];
  selectedIssueId: string | null;
  onSelectIssue: (id: string | null) => void;
  onResolveIssue: (id: string) => void;
  onDeleteIssue: (id: string) => void;
}

export default function IssuesLog({
  issues,
  selectedIssueId,
  onSelectIssue,
  onResolveIssue,
  onDeleteIssue,
}: IssuesLogProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [systemFilter, setSystemFilter] = useState<SystemType | 'All'>('All');
  const [priorityFilter, setPriorityFilter] = useState<'All' | 'Haute' | 'Moyenne' | 'Basse'>('All');
  const [statusFilter, setStatusFilter] = useState<'All' | 'Nouveau' | 'En cours' | 'Résolu'>('All');

  const selectedIssue = issues.find((issue) => issue.id === selectedIssueId);

  // Statistics
  const totalCount = issues.length;
  const resolvedCount = issues.filter((i) => i.status === 'Résolu').length;
  const pendingCount = totalCount - resolvedCount;
  const urgentCount = issues.filter((i) => i.priority === 'Haute' && i.status !== 'Résolu').length;
  const complianceRate = totalCount > 0 ? Math.round((resolvedCount / totalCount) * 100) : 100;

  // Filtered Issues List
  const filteredIssues = issues.filter((issue) => {
    const matchesSearch =
      issue.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      issue.elementName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      issue.description.toLowerCase().includes(searchTerm.toLowerCase());

    const matchesSystem = systemFilter === 'All' || issue.system === systemFilter;
    const matchesPriority = priorityFilter === 'All' || issue.priority === priorityFilter;
    const matchesStatus = statusFilter === 'All' || issue.status === statusFilter;

    return matchesSearch && matchesSystem && matchesPriority && matchesStatus;
  });

  const getPriorityBadge = (priority: 'Haute' | 'Moyenne' | 'Basse') => {
    switch (priority) {
      case 'Haute':
        return 'bg-red-500/10 border-red-500/30 text-red-400';
      case 'Moyenne':
        return 'bg-amber-500/10 border-amber-500/30 text-amber-400';
      case 'Basse':
        return 'bg-blue-500/10 border-blue-500/30 text-blue-400';
    }
  };

  const getStatusIcon = (status: 'Nouveau' | 'En cours' | 'Résolu') => {
    switch (status) {
      case 'Résolu':
        return <CheckCircle2 className="w-4 h-4 text-emerald-400" />;
      case 'En cours':
        return <Clock className="w-4 h-4 text-blue-400" />;
      case 'Nouveau':
        return <AlertCircle className="w-4 h-4 text-red-400" />;
    }
  };

  const getSystemLabel = (system: SystemType) => {
    switch (system) {
      case 'HVAC':
        return 'HVAC / Ventilation';
      case 'Plumbing':
        return 'Plomberie';
      case 'Electrical':
        return 'Électricité';
      case 'FireProtection':
        return 'Sprinkler Incendie';
      case 'Structural':
        return 'Structure';
    }
  };

  return (
    <div className="flex flex-col gap-6">
      {/* HUD Stats Row */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-slate-900/60 backdrop-blur-md p-4 rounded-xl border border-slate-800 flex justify-between items-center">
          <div>
            <span className="text-[10px] uppercase font-bold text-slate-500">Total Écarts</span>
            <p className="text-xl font-bold text-white font-mono">{totalCount}</p>
          </div>
          <div className="w-10 h-10 rounded-lg bg-slate-950 flex items-center justify-center text-slate-400">
            <Inbox className="w-5 h-5" />
          </div>
        </div>

        <div className="bg-slate-900/60 backdrop-blur-md p-4 rounded-xl border border-slate-800 flex justify-between items-center">
          <div>
            <span className="text-[10px] uppercase font-bold text-slate-500">Urgent (Haute)</span>
            <p className="text-xl font-bold text-red-400 font-mono">{urgentCount}</p>
          </div>
          <div className="w-10 h-10 rounded-lg bg-red-500/10 border border-red-500/20 flex items-center justify-center text-red-400">
            <AlertCircle className="w-5 h-5" />
          </div>
        </div>

        <div className="bg-slate-900/60 backdrop-blur-md p-4 rounded-xl border border-slate-800 flex justify-between items-center">
          <div>
            <span className="text-[10px] uppercase font-bold text-slate-500">En cours / Résolus</span>
            <p className="text-xl font-bold text-emerald-400 font-mono">
              {resolvedCount} <span className="text-slate-500 text-xs font-normal">/ {totalCount}</span>
            </p>
          </div>
          <div className="w-10 h-10 rounded-lg bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-400">
            <CheckCircle2 className="w-5 h-5" />
          </div>
        </div>

        <div className="bg-slate-900/60 backdrop-blur-md p-4 rounded-xl border border-slate-800 flex justify-between items-center">
          <div>
            <span className="text-[10px] uppercase font-bold text-slate-500">Taux de Résolution</span>
            <p className="text-xl font-bold text-blue-400 font-mono">{complianceRate}%</p>
          </div>
          <div className="w-10 h-10 rounded-lg bg-blue-500/10 border border-blue-500/20 flex items-center justify-center text-blue-400">
            <span className="text-xs font-bold font-mono">{complianceRate}%</span>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Side: Issues List & Filters */}
        <div className="lg:col-span-2 bg-slate-900/60 backdrop-blur-md border border-slate-800 rounded-2xl p-5 flex flex-col gap-4">
          <div className="flex flex-col md:flex-row gap-3 items-stretch md:items-center justify-between">
            <h3 className="font-display font-semibold text-base text-white">Registre des Écarts</h3>
            
            {/* Search input */}
            <div className="relative flex-1 md:max-w-xs">
              <Search className="w-4 h-4 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="Rechercher un écart..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full bg-slate-950 border border-slate-850 rounded-xl pl-9 pr-4 py-2 text-xs text-white focus:outline-none focus:border-blue-500"
              />
            </div>
          </div>

          {/* Quick Filters Row */}
          <div className="flex flex-wrap gap-2.5 items-center border-b border-slate-800/60 pb-4">
            {/* System Filter */}
            <div className="flex items-center gap-1.5">
              <span className="text-[10px] uppercase font-semibold text-slate-500">Réseau :</span>
              <select
                value={systemFilter}
                onChange={(e) => setSystemFilter(e.target.value as SystemType | 'All')}
                className="bg-slate-950 border border-slate-800 rounded-lg px-2 py-1 text-[11px] text-slate-300 focus:outline-none"
              >
                <option value="All">Tous les réseaux</option>
                <option value="HVAC">HVAC / Ventilation</option>
                <option value="Plumbing">Plomberie</option>
                <option value="Electrical">Électricité</option>
                <option value="FireProtection">Sprinkler Incendie</option>
              </select>
            </div>

            {/* Priority Filter */}
            <div className="flex items-center gap-1.5">
              <span className="text-[10px] uppercase font-semibold text-slate-500">Priorité :</span>
              <select
                value={priorityFilter}
                onChange={(e) => setPriorityFilter(e.target.value as 'All' | 'Haute' | 'Moyenne' | 'Basse')}
                className="bg-slate-950 border border-slate-800 rounded-lg px-2 py-1 text-[11px] text-slate-300 focus:outline-none"
              >
                <option value="All">Toutes priorités</option>
                <option value="Haute">Haute</option>
                <option value="Moyenne">Moyenne</option>
                <option value="Basse">Basse</option>
              </select>
            </div>

            {/* Status Filter */}
            <div className="flex items-center gap-1.5">
              <span className="text-[10px] uppercase font-semibold text-slate-500">Statut :</span>
              <select
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value as 'All' | 'Nouveau' | 'En cours' | 'Résolu')}
                className="bg-slate-950 border border-slate-800 rounded-lg px-2 py-1 text-[11px] text-slate-300 focus:outline-none"
              >
                <option value="All">Tous statuts</option>
                <option value="Nouveau">Nouveau</option>
                <option value="En cours">En cours</option>
                <option value="Résolu">Résolu</option>
              </select>
            </div>
          </div>

          {/* Issues table / items */}
          <div className="space-y-2 overflow-y-auto max-h-[400px] pr-1">
            {filteredIssues.length === 0 ? (
              <div className="text-center py-12 text-slate-500">
                <Inbox className="w-10 h-10 mx-auto mb-3 opacity-30" />
                <p className="text-xs">Aucun écart ne correspond à vos filtres de recherche.</p>
              </div>
            ) : (
              filteredIssues.map((issue) => {
                const isSelected = selectedIssueId === issue.id;
                return (
                  <div
                    key={issue.id}
                    onClick={() => onSelectIssue(isSelected ? null : issue.id)}
                    className={`p-3.5 rounded-xl border transition-all cursor-pointer flex flex-col md:flex-row justify-between items-start md:items-center gap-3 ${
                      isSelected
                        ? 'bg-blue-600/10 border-blue-500/80 shadow-md'
                        : 'bg-slate-950/40 border-slate-850 hover:border-slate-800'
                    }`}
                  >
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-1.5">
                        <span className="font-mono text-[9px] text-slate-500">#{issue.id.slice(-6).toUpperCase()}</span>
                        <span className={`px-2 py-0.5 rounded text-[9px] font-bold uppercase border ${getPriorityBadge(issue.priority)}`}>
                          {issue.priority}
                        </span>
                        <span className="text-[10px] font-semibold text-blue-400">
                          {getSystemLabel(issue.system)}
                        </span>
                      </div>
                      
                      <h4 className="font-display font-semibold text-xs text-slate-200 truncate">{issue.title}</h4>
                      
                      <div className="flex items-center gap-3 mt-2 text-[10px] text-slate-400 truncate">
                        <span className="flex items-center gap-1">
                          <MapPin className="w-3 h-3 text-slate-500" />
                          {issue.location}
                        </span>
                        <span className="text-slate-600">•</span>
                        <span>{issue.date}</span>
                      </div>
                    </div>

                    <div className="flex items-center gap-4 shrink-0 self-stretch md:self-auto justify-between border-t border-slate-900 md:border-t-0 pt-2 md:pt-0">
                      <div className="flex items-center gap-1.5 text-xs text-slate-300">
                        {getStatusIcon(issue.status)}
                        <span className="font-semibold text-[11px]">{issue.status}</span>
                      </div>
                      
                      <ChevronRight className={`w-4 h-4 text-slate-500 transition-transform ${isSelected ? 'rotate-90 text-blue-400' : ''}`} />
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>

        {/* Right Side: Issue Detail Card / Drawer */}
        <div className="lg:col-span-1">
          <AnimatePresence mode="wait">
            {selectedIssue ? (
              <motion.div
                key="detail-open"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: 20 }}
                className="bg-slate-900/60 backdrop-blur-md border border-slate-800 rounded-2xl p-5 flex flex-col gap-4 min-h-[460px] justify-between shadow-xl"
              >
                <div>
                  <div className="flex justify-between items-start border-b border-slate-800/60 pb-3 mb-4">
                    <div>
                      <span className="text-[10px] font-mono text-slate-500">FICHE TECHNIQUE D'ÉCART</span>
                      <h3 className="font-display font-bold text-sm text-white mt-1">{selectedIssue.title}</h3>
                    </div>
                    <button
                      onClick={() => onSelectIssue(null)}
                      className="text-xs text-slate-500 hover:text-white"
                    >
                      Fermer
                    </button>
                  </div>

                  <div className="space-y-4">
                    {/* Status / Priority HUD */}
                    <div className="flex gap-2">
                      <div className="flex-1 bg-slate-950/40 p-2 rounded-xl text-center border border-slate-850">
                        <span className="text-[9px] uppercase font-semibold text-slate-500 block mb-0.5">Statut actuel</span>
                        <div className="flex items-center justify-center gap-1 text-xs text-slate-200">
                          {getStatusIcon(selectedIssue.status)}
                          <span className="font-bold">{selectedIssue.status}</span>
                        </div>
                      </div>

                      <div className="flex-1 bg-slate-950/40 p-2 rounded-xl text-center border border-slate-850">
                        <span className="text-[9px] uppercase font-semibold text-slate-500 block mb-0.5">Priorité</span>
                        <span className={`text-xs font-bold ${getPriorityBadge(selectedIssue.priority)} inline-block px-1.5 py-0.5 rounded border mt-0.5`}>
                          {selectedIssue.priority}
                        </span>
                      </div>
                    </div>

                    {/* Metadata lists */}
                    <div className="space-y-2.5 text-xs">
                      <div>
                        <span className="text-[10px] uppercase font-bold text-slate-500 block mb-0.5">Élément Maquette (BIM)</span>
                        <span className="text-slate-300 font-medium">{selectedIssue.elementName}</span>
                      </div>

                      <div className="grid grid-cols-2 gap-3 pt-1">
                        <div>
                          <span className="text-[10px] uppercase font-bold text-slate-500 block mb-0.5">Signalé par</span>
                          <span className="text-slate-300 flex items-center gap-1">
                            <User className="w-3 h-3 text-slate-500" />
                            {selectedIssue.reportedBy}
                          </span>
                        </div>
                        <div>
                          <span className="text-[10px] uppercase font-bold text-slate-500 block mb-0.5">Date du rapport</span>
                          <span className="text-slate-300 flex items-center gap-1">
                            <Calendar className="w-3 h-3 text-slate-500" />
                            {selectedIssue.date}
                          </span>
                        </div>
                      </div>

                      <div className="pt-1">
                        <span className="text-[10px] uppercase font-bold text-slate-500 block mb-0.5">Localisation physique</span>
                        <span className="text-slate-300 flex items-center gap-1">
                          <MapPin className="w-3 h-3 text-slate-500" />
                          {selectedIssue.location}
                        </span>
                      </div>

                      <div className="pt-2 border-t border-slate-800/40">
                        <span className="text-[10px] uppercase font-bold text-slate-500 block mb-1">Description du constat</span>
                        <p className="text-slate-300 text-xs leading-relaxed bg-slate-950/30 p-2.5 rounded-lg border border-slate-850">
                          {selectedIssue.description}
                        </p>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Operations Actions bar */}
                <div className="space-y-2 pt-4 border-t border-slate-800/60">
                  {selectedIssue.status !== 'Résolu' && (
                    <button
                      onClick={() => onResolveIssue(selectedIssue.id)}
                      className="w-full py-2.5 px-4 bg-emerald-500 hover:bg-emerald-600 text-slate-950 font-bold text-xs rounded-xl flex items-center justify-center gap-1.5 transition-all shadow-md shadow-emerald-500/10"
                    >
                      <CheckCircle2 className="w-4.5 h-4.5" />
                      Valider la conformité (Résoudre)
                    </button>
                  )}

                  <button
                    onClick={() => onDeleteIssue(selectedIssue.id)}
                    className="w-full py-2 px-4 bg-slate-950 hover:bg-red-500/10 hover:text-red-400 border border-slate-850 rounded-xl text-slate-400 text-xs font-semibold flex items-center justify-center gap-1.5 transition-all"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    Supprimer le signalement
                  </button>
                </div>
              </motion.div>
            ) : (
              <motion.div
                key="detail-empty"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="bg-slate-900/40 border border-slate-800 border-dashed rounded-2xl p-6 flex flex-col items-center justify-center min-h-[460px] text-center"
              >
                <HelpCircle className="w-10 h-10 text-slate-600 mb-3" />
                <h4 className="font-display font-semibold text-sm text-slate-400 mb-1">Aucun écart sélectionné</h4>
                <p className="text-[11px] text-slate-500 max-w-[200px] leading-relaxed">
                  Sélectionnez un élément dans le registre des écarts à gauche pour inspecter sa fiche technique et procéder à sa résolution.
                </p>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>
    </div>
  );
}
