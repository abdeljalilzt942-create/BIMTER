import React, { useState } from 'react';
import { Upload, FileCode, CheckCircle2, AlertCircle, RefreshCw, BarChart2, Check, Network, ShieldCheck } from 'lucide-react';
import { MockModel, SystemType } from '../types';
import { motion, AnimatePresence } from 'motion/react';

const PRESET_MODELS: MockModel[] = [
  {
    id: 'model-1',
    name: 'Clinique_Lille_Ventilation_MEP.ifc',
    fileSize: '42.8 MB',
    fileType: 'IFC',
    version: 'IFC4 - Design Stage',
    elementCount: 4892,
    clashCount: 12,
    systemCounts: {
      HVAC: 1840,
      Plumbing: 1210,
      Electrical: 1540,
      FireProtection: 302,
      Structural: 0,
    },
  },
  {
    id: 'model-2',
    name: 'Tour_Bureaux_LaDefense_Structure.rvt',
    fileSize: '184.5 MB',
    fileType: 'RVT',
    version: 'Revit 2024 - LOD 400',
    elementCount: 12543,
    clashCount: 34,
    systemCounts: {
      HVAC: 0,
      Plumbing: 0,
      Electrical: 2150,
      FireProtection: 0,
      Structural: 10393,
    },
  },
  {
    id: 'model-3',
    name: 'Residence_Lyon_Plomberie_Sanitaire.ifc',
    fileSize: '19.3 MB',
    fileType: 'IFC',
    version: 'IFC2x3 - Coordination',
    elementCount: 2145,
    clashCount: 4,
    systemCounts: {
      HVAC: 0,
      Plumbing: 1450,
      Electrical: 320,
      FireProtection: 375,
      Structural: 0,
    },
  },
];

const SYNC_STAGES = [
  'Vérification de l\'intégrité du fichier...',
  'Lecture des entêtes IFC & Schémas Express...',
  'Extraction des classes de segments de flux (IfcFlowSegment)...',
  'Validation géométrique et repérage des coordonnées géographiques...',
  'Calcul de l\'algorithme d\'auto-alignement des repères de chantier...',
  'Résolution des interférences majeures (Clashes)...',
  'Finalisation de la synchronisation cloud...',
];

export default function IFCSync({
  onModelLoaded,
}: {
  onModelLoaded: (model: MockModel) => void;
}) {
  const [activeModel, setActiveModel] = useState<MockModel | null>(PRESET_MODELS[0]);
  const [syncProgress, setSyncProgress] = useState<number>(-1);
  const [syncStageIndex, setSyncStageIndex] = useState<number>(0);
  const [dragActive, setDragActive] = useState<boolean>(false);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);

  const startSyncSimulation = (model: MockModel) => {
    setSuccessMessage(null);
    setSyncProgress(0);
    setSyncStageIndex(0);

    const intervalTime = 300; // fast but readable speed
    const timer = setInterval(() => {
      setSyncProgress((prev) => {
        if (prev >= 100) {
          clearInterval(timer);
          onModelLoaded(model);
          setActiveModel(model);
          setSuccessMessage(`Modèle "${model.name}" synchronisé avec succès !`);
          setTimeout(() => setSyncProgress(-1), 1000);
          return 100;
        }

        // Advance stage index based on progress
        const nextStage = Math.min(
          Math.floor((prev / 100) * SYNC_STAGES.length),
          SYNC_STAGES.length - 1
        );
        setSyncStageIndex(nextStage);

        return prev + 5;
      });
    }, intervalTime);
  };

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === 'dragenter' || e.type === 'dragover') {
      setDragActive(true);
    } else if (e.type === 'dragleave') {
      setDragActive(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);

    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      const file = e.dataTransfer.files[0];
      const ext = file.name.split('.').pop()?.toUpperCase();
      
      if (ext === 'IFC' || ext === 'RVT') {
        const customModel: MockModel = {
          id: `model-custom-${Date.now()}`,
          name: file.name,
          fileSize: `${(file.size / (1024 * 1024)).toFixed(1)} MB`,
          fileType: ext as 'IFC' | 'RVT',
          version: `Importé - LOD ${ext === 'IFC' ? '350' : '400'}`,
          elementCount: Math.floor(Math.random() * 8000) + 1500,
          clashCount: Math.floor(Math.random() * 20),
          systemCounts: {
            HVAC: Math.floor(Math.random() * 2000),
            Plumbing: Math.floor(Math.random() * 1500),
            Electrical: Math.floor(Math.random() * 2000),
            FireProtection: Math.floor(Math.random() * 400),
            Structural: Math.floor(Math.random() * 5000),
          },
        };
        startSyncSimulation(customModel);
      } else {
        alert('Format non supporté. Veuillez importer un fichier .ifc ou .rvt (Revit).');
      }
    }
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
      {/* Upload and Template Selection */}
      <div className="lg:col-span-1 flex flex-col gap-5">
        <div className="bg-slate-900/60 backdrop-blur-md p-5 rounded-2xl border border-slate-800">
          <h3 className="font-display font-semibold text-base text-white mb-3">Importer un modèle</h3>
          <p className="text-xs text-slate-400 mb-4">
            Glissez-déposez votre maquette au format standard IFC ou Revit pour l'exporter vers vos casques et tablettes AR de chantier.
          </p>

          {/* Drag & Drop Box */}
          <div
            onDragEnter={handleDrag}
            onDragOver={handleDrag}
            onDragLeave={handleDrag}
            onDrop={handleDrop}
            className={`border-2 border-dashed rounded-xl p-6 text-center transition-all cursor-pointer ${
              dragActive
                ? 'border-blue-400 bg-blue-500/10'
                : 'border-slate-800 bg-slate-950/40 hover:border-slate-700'
            }`}
            onClick={() => {
              // Simulate file picker click
              const mockFiles = [
                'Chantier_Paris_Bureaux_MEP.ifc',
                'Residence_Bordeaux_Structure.rvt',
                'EHPAD_Nantes_Ventilation.ifc',
              ];
              const randomName = mockFiles[Math.floor(Math.random() * mockFiles.length)];
              const customModel: MockModel = {
                id: `model-custom-${Date.now()}`,
                name: randomName,
                fileSize: '34.6 MB',
                fileType: randomName.endsWith('.ifc') ? 'IFC' : 'RVT',
                version: 'IFC4 - Import local',
                elementCount: 3840,
                clashCount: 8,
                systemCounts: {
                  HVAC: 1200,
                  Plumbing: 840,
                  Electrical: 1400,
                  FireProtection: 400,
                  Structural: 0,
                },
              };
              startSyncSimulation(customModel);
            }}
          >
            <Upload className="w-8 h-8 text-slate-500 mx-auto mb-3" />
            <span className="text-xs font-semibold text-slate-300 block mb-1">
              Parcourir ou glisser-déposer
            </span>
            <span className="text-[10px] text-slate-500 block">Fichiers supportés : .IFC, .RVT</span>
          </div>
        </div>

        {/* Preset list */}
        <div className="bg-slate-900/60 backdrop-blur-md p-5 rounded-2xl border border-slate-800">
          <h3 className="font-display font-semibold text-sm text-white mb-3">Modèles de Démo BIMTER</h3>
          <p className="text-[11px] text-slate-400 mb-4">
            Sélectionnez un modèle pré-chargé pour tester instantanément la puissance de notre algorithme d'alignement.
          </p>

          <div className="space-y-2">
            {PRESET_MODELS.map((model) => {
              const isSelected = activeModel?.id === model.id;
              return (
                <button
                  key={model.id}
                  onClick={() => startSyncSimulation(model)}
                  className={`w-full text-left p-3 rounded-xl border text-xs font-medium transition-all flex items-center justify-between ${
                    isSelected
                      ? 'bg-blue-600/15 border-blue-500 text-white shadow-lg'
                      : 'bg-slate-950/40 border-slate-850 text-slate-400 hover:border-slate-800'
                  }`}
                >
                  <div className="flex items-center gap-2.5 min-w-0">
                    <FileCode className={`w-4 h-4 shrink-0 ${isSelected ? 'text-blue-400' : 'text-slate-500'}`} />
                    <div className="truncate">
                      <p className="font-semibold text-slate-200 truncate">{model.name}</p>
                      <p className="text-[10px] text-slate-500">{model.fileSize} • {model.version}</p>
                    </div>
                  </div>
                  {isSelected && <Check className="w-4 h-4 text-blue-400 shrink-0" />}
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {/* Parsing Stats and Visual Diagnostics Dashboard */}
      <div className="lg:col-span-2">
        <AnimatePresence mode="wait">
          {syncProgress >= 0 ? (
            /* ACTIVE SYNCING SIMULATION LOADER */
            <motion.div
              key="sync-loader"
              initial={{ opacity: 0, scale: 0.98 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.98 }}
              className="bg-slate-900/90 border border-blue-500/40 rounded-2xl p-8 flex flex-col items-center justify-center min-h-[380px] text-center shadow-xl shadow-blue-500/5"
            >
              <div className="relative mb-6">
                <div className="w-16 h-16 rounded-full border-4 border-slate-800 border-t-blue-500 animate-spin flex items-center justify-center"></div>
                <div className="absolute inset-0 flex items-center justify-center text-xs font-bold text-blue-400">
                  {syncProgress}%
                </div>
              </div>

              <h4 className="font-display font-bold text-lg text-white mb-2">
                Analyse & Synchronisation BIMTER
              </h4>
              <p className="text-xs text-blue-400 font-mono mb-4 uppercase tracking-widest animate-pulse">
                {SYNC_STAGES[syncStageIndex]}
              </p>

              <div className="w-full max-w-sm bg-slate-950 h-2 rounded-full overflow-hidden border border-slate-800">
                <div
                  className="bg-gradient-to-r from-blue-600 to-cyan-400 h-full rounded-full transition-all duration-300"
                  style={{ width: `${syncProgress}%` }}
                ></div>
              </div>

              <span className="text-[10px] text-slate-500 mt-6 leading-relaxed block max-w-xs">
                Extraction des classes IFC, indexation spatiale des réseaux techniques et compilation des plans d'exécution.
              </span>
            </motion.div>
          ) : (
            /* DETAILED PARSING RESULTS PORTAL */
            activeModel && (
              <motion.div
                key="sync-results"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="bg-slate-900/60 backdrop-blur-md border border-slate-800 rounded-2xl p-6"
              >
                <div className="flex justify-between items-start mb-6">
                  <div>
                    <div className="flex items-center gap-2 mb-1">
                      <span className="bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-[10px] uppercase font-bold px-2 py-0.5 rounded-full flex items-center gap-1">
                        <ShieldCheck className="w-3 h-3" />
                        Synchronisé
                      </span>
                      <span className="text-xs text-slate-500">ID: {activeModel.id}</span>
                    </div>
                    <h3 className="font-display font-bold text-lg text-white">{activeModel.name}</h3>
                  </div>

                  <button
                    onClick={() => startSyncSimulation(activeModel)}
                    className="p-2 bg-slate-950 hover:bg-slate-850 rounded-lg text-slate-400 hover:text-white transition-all border border-slate-800 flex items-center gap-1.5 text-xs font-semibold"
                  >
                    <RefreshCw className="w-3.5 h-3.5" />
                    Réanalyser
                  </button>
                </div>

                {successMessage && (
                  <div className="p-3 bg-emerald-500/10 border border-emerald-500/20 rounded-xl flex items-center gap-2.5 mb-5 text-emerald-400 text-xs">
                    <CheckCircle2 className="w-4.5 h-4.5" />
                    <span>{successMessage}</span>
                  </div>
                )}

                {/* Grid stats */}
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
                  <div className="bg-slate-950/40 p-3.5 rounded-xl border border-slate-850">
                    <span className="text-[10px] uppercase font-semibold text-slate-500 block mb-1">Objets Parsés</span>
                    <span className="text-base font-bold text-white font-mono">{activeModel.elementCount.toLocaleString()}</span>
                  </div>
                  <div className="bg-slate-950/40 p-3.5 rounded-xl border border-slate-850">
                    <span className="text-[10px] uppercase font-semibold text-slate-500 block mb-1">Type de Fichier</span>
                    <span className="text-base font-bold text-blue-400 font-mono">{activeModel.fileType}</span>
                  </div>
                  <div className="bg-slate-950/40 p-3.5 rounded-xl border border-slate-850">
                    <span className="text-[10px] uppercase font-semibold text-slate-500 block mb-1">Clashes initiaux</span>
                    <span className={`text-base font-bold font-mono ${activeModel.clashCount > 0 ? 'text-amber-400' : 'text-emerald-400'}`}>
                      {activeModel.clashCount}
                    </span>
                  </div>
                  <div className="bg-slate-950/40 p-3.5 rounded-xl border border-slate-850">
                    <span className="text-[10px] uppercase font-semibold text-slate-500 block mb-1">Taille</span>
                    <span className="text-base font-bold text-slate-300 font-mono">{activeModel.fileSize}</span>
                  </div>
                </div>

                {/* Sub-distribution chart */}
                <div className="bg-slate-950/40 border border-slate-850 rounded-xl p-5 mb-6">
                  <div className="flex items-center gap-2 mb-4">
                    <BarChart2 className="w-4.5 h-4.5 text-blue-400" />
                    <h4 className="font-display font-semibold text-xs text-slate-300 uppercase tracking-wider">
                      Répartition des éléments MEP par réseau
                    </h4>
                  </div>

                  <div className="space-y-3">
                    {(Object.keys(activeModel.systemCounts) as SystemType[]).map((sys) => {
                      const count = activeModel.systemCounts[sys];
                      if (count === 0) return null;
                      
                      const sysLabels: Record<SystemType, string> = {
                        HVAC: 'CVC / Ventilation',
                        Plumbing: 'Plomberie & Fluides',
                        Electrical: 'Électricité (Basse/Haute tension)',
                        FireProtection: 'Réseaux Sprinkler / Incendie',
                        Structural: 'Éléments Structuraux (Béton)',
                      };

                      const colorClasses: Record<SystemType, string> = {
                        HVAC: 'bg-green-500',
                        Plumbing: 'bg-blue-500',
                        Electrical: 'bg-yellow-500',
                        FireProtection: 'bg-red-500',
                        Structural: 'bg-slate-500',
                      };

                      const percent = Math.round((count / activeModel.elementCount) * 100);

                      return (
                        <div key={sys} className="space-y-1">
                          <div className="flex justify-between text-xs text-slate-400">
                            <span>{sysLabels[sys]}</span>
                            <span className="font-mono font-bold text-slate-300">
                              {count.toLocaleString()} <span className="text-slate-500 text-[10px]">({percent}%)</span>
                            </span>
                          </div>
                          <div className="w-full bg-slate-900 h-1.5 rounded-full overflow-hidden">
                            <div className={`h-full rounded-full ${colorClasses[sys]}`} style={{ width: `${percent}%` }}></div>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>

                {/* Diagnostics note */}
                <div className="p-3 bg-slate-950/60 rounded-xl border border-slate-850 flex gap-2.5 items-start">
                  <Network className="w-4 h-4 text-blue-400 shrink-0 mt-0.5" />
                  <div className="text-[11px] text-slate-400 leading-relaxed">
                    <p className="font-semibold text-slate-300 mb-0.5">Algorithme d'alignement spatial actif</p>
                    Les points de pivot et géométries IFC ont été automatiquement traduits en coordonnées de réalité augmentée. Les tablettes de chantier et casques connectés se calibreront instantanément à la volée.
                  </div>
                </div>
              </motion.div>
            )
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
