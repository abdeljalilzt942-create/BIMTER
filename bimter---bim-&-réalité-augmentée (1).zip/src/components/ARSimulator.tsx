import React, { useState, useRef, useEffect } from 'react';
import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';
import { 
  Eye, 
  EyeOff, 
  Layers, 
  Info, 
  AlertTriangle, 
  Plus, 
  CheckCircle, 
  Smartphone, 
  Sliders, 
  Compass, 
  Rotate3d, 
  Box, 
  Video, 
  Maximize2,
  HelpCircle
} from 'lucide-react';
import { BIMElement, SiteIssue, SystemType } from '../types';
import { motion, AnimatePresence } from 'motion/react';

interface ARSimulatorProps {
  issues: SiteIssue[];
  onAddIssue: (issue: SiteIssue) => void;
  selectedIssueId: string | null;
  onSelectIssue: (id: string | null) => void;
}

// 2D percentage coordinates mapped to high-fidelity 3D positions in our virtual corridor
const PRESET_ELEMENTS: BIMElement[] = [
  {
    id: 'elem-1',
    name: 'Gaine de Ventilation Primaire (HVAC-SUP-04)',
    system: 'HVAC',
    diameter: '500mm x 400mm',
    flowRate: '1500 m³/h',
    material: 'Acier Galvanisé avec Isolation Thermique',
    elevation: '+3.15 m sous dalle',
    status: 'Conforme',
    coordinates: { x: 68, y: 16 }, // Maps to 3D: (1.4, 1.4, -3)
  },
  {
    id: 'elem-2',
    name: 'Collecteur Eau Froide Générale (PL-EF-012)',
    system: 'Plumbing',
    diameter: 'Ø 80mm',
    material: 'Cuivre soudé haute pression',
    elevation: '+2.85 m',
    status: 'Écart Détecté',
    coordinates: { x: 35, y: 52 }, // Maps to 3D: (-2.2, -0.6, -5)
  },
  {
    id: 'elem-3',
    name: 'Chemin de Câble Force & Énergie (ELE-CF-02)',
    system: 'Electrical',
    voltage: '400V / 50Hz',
    material: 'Dalle d\'aluminium perforée',
    elevation: '+3.45 m',
    status: 'Conforme',
    coordinates: { x: 44.5, y: 62 }, // Maps to 3D: (-1.6, 1.1, -2)
  },
  {
    id: 'elem-4',
    name: 'Antenne de Sprinkler Automatique (INC-SP-09)',
    system: 'FireProtection',
    diameter: 'Ø 40mm',
    material: 'Acier noir fileté',
    elevation: '+3.55 m',
    status: 'Conforme',
    coordinates: { x: 63.5, y: 45 }, // Maps to 3D: (0, 1.7, -5)
  },
];

// Helper to convert 2D percentages to our virtual 3D corridor space
const get3DPosition = (px: number, py: number): THREE.Vector3 => {
  // Return pre-calculated 3D positions for the default hotspots to align perfectly with the meshes
  if (px === 68 && py === 16) return new THREE.Vector3(1.4, 1.4, -3); // HVAC
  if (px === 35 && py === 52) return new THREE.Vector3(-2.2, -0.6, -5); // Plumbing
  if (px === 44.5 && py === 62) return new THREE.Vector3(-1.6, 1.1, -2); // Electrical
  if (px === 63.5 && py === 45) return new THREE.Vector3(0, 1.7, -5); // Fire Protection

  // Interpolate for new custom pins clicked in 3D
  const x = (px / 100) * 8 - 4; // x range: -4 to 4
  const y = ((100 - py) / 100) * 5 - 2.5; // y range: -2.5 to 2.5
  return new THREE.Vector3(x, y, -4.5); // Fixed depth plane in the middle
};

type CameraPreset = 'global' | 'ceiling' | 'piping' | 'front';

export default function ARSimulator({
  issues,
  onAddIssue,
  selectedIssueId,
  onSelectIssue,
}: ARSimulatorProps) {
  const [arOpacity, setArOpacity] = useState<number>(85);
  const [selectedSystems, setSelectedSystems] = useState<Record<SystemType, boolean>>({
    HVAC: true,
    Plumbing: true,
    Electrical: true,
    Structural: true,
    FireProtection: true,
  });

  const [inspectingElement, setInspectingElement] = useState<BIMElement | null>(null);
  const [isAddingIssueMode, setIsAddingIssueMode] = useState<boolean>(false);
  const [clickCoordinates, setClickCoordinates] = useState<{ x: number; y: number } | null>(null);
  
  // Custom camera preset selected
  const [activePreset, setActivePreset] = useState<CameraPreset>('global');

  // Form states for creating a custom discrepancy
  const [newIssueTitle, setNewIssueTitle] = useState('');
  const [newIssueDesc, setNewIssueDesc] = useState('');
  const [newIssueSystem, setNewIssueSystem] = useState<SystemType>('HVAC');
  const [newIssuePriority, setNewIssuePriority] = useState<'Haute' | 'Moyenne' | 'Basse'>('Moyenne');

  // DOM Refs
  const containerRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  // Three.js mutable references
  const threeEngineRef = useRef<{
    scene: THREE.Scene;
    camera: THREE.PerspectiveCamera;
    renderer: THREE.WebGLRenderer;
    controls: OrbitControls;
    hvacGroup: THREE.Group;
    plumbingGroup: THREE.Group;
    electricalGroup: THREE.Group;
    fireGroup: THREE.Group;
    pinGroup: THREE.Group;
    targetCameraPos: THREE.Vector3;
    targetCameraLook: THREE.Vector3;
  } | null>(null);

  const toggleSystem = (system: SystemType) => {
    setSelectedSystems((prev) => ({ ...prev, [system]: !prev[system] }));
  };

  // Preset Camera Angles
  const applyCameraPreset = (preset: CameraPreset) => {
    setActivePreset(preset);
    const engine = threeEngineRef.current;
    if (!engine) return;

    switch (preset) {
      case 'global': // Classic diagonal perspective
        engine.targetCameraPos.set(4, 3, 7);
        engine.targetCameraLook.set(0, 0, -3);
        break;
      case 'ceiling': // Top-down look focusing on HVAC & Sprinklers
        engine.targetCameraPos.set(0, 4.5, -4);
        engine.targetCameraLook.set(0, 1.4, -4.1);
        break;
      case 'piping': // Side view focusing on plumbing pipes on left wall
        engine.targetCameraPos.set(-4.5, 0, -4);
        engine.targetCameraLook.set(-2.2, -0.6, -4);
        break;
      case 'front': // Isometric front hallway alignment look
        engine.targetCameraPos.set(0, 0.2, 7.5);
        engine.targetCameraLook.set(0, 0, -5);
        break;
    }
  };

  // Handles clicking the 3D viewport canvas
  const handleCanvasClick = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!isAddingIssueMode || !containerRef.current || !threeEngineRef.current) return;

    const rect = containerRef.current.getBoundingClientRect();
    const clientX = e.clientX - rect.left;
    const clientY = e.clientY - rect.top;

    // 1. Calculate normalized device coordinates
    const mouseX = (clientX / rect.width) * 2 - 1;
    const mouseY = -(clientY / rect.height) * 2 + 1;

    // 2. Raycast to find the 3D coordinate on a mid-plane at z = -4.5
    const { camera } = threeEngineRef.current;
    const raycaster = new THREE.Raycaster();
    raycaster.setFromCamera(new THREE.Vector2(mouseX, mouseY), camera);

    const plane = new THREE.Plane(new THREE.Vector3(0, 0, 1), 4.5);
    const targetPoint = new THREE.Vector3();
    
    if (raycaster.ray.intersectPlane(plane, targetPoint)) {
      // Convert 3D coordinate to percentage coordinates for compatibility
      const px = Math.round(((targetPoint.x + 4) / 8) * 100);
      const py = Math.round((1 - (targetPoint.y + 2.5) / 5) * 100);

      // Clamp values between 0 and 100
      const clampedX = Math.max(5, Math.min(95, px));
      const clampedY = Math.max(5, Math.min(95, py));

      setClickCoordinates({ x: clampedX, y: clampedY });
    }
  };

  const handleCreateIssueSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!clickCoordinates || !newIssueTitle.trim()) return;

    const newIssue: SiteIssue = {
      id: `issue-custom-${Date.now()}`,
      title: newIssueTitle,
      system: newIssueSystem,
      priority: newIssuePriority,
      status: 'Nouveau',
      elementName: `Élément personnalisé au point (${clickCoordinates.x}%, ${clickCoordinates.y}%)`,
      location: 'Niveau 2 - Zone Centrale (3D Space)',
      reportedBy: 'Superviseur de Chantier (Vous)',
      date: new Date().toLocaleDateString('fr-FR'),
      description: newIssueDesc || 'Aucune description fournie.',
      coordinateX: clickCoordinates.x,
      coordinateY: clickCoordinates.y,
    };

    onAddIssue(newIssue);
    setIsAddingIssueMode(false);
    setClickCoordinates(null);
    setNewIssueTitle('');
    setNewIssueDesc('');
    onSelectIssue(newIssue.id);
  };

  const cancelAddingIssue = () => {
    setIsAddingIssueMode(false);
    setClickCoordinates(null);
    setNewIssueTitle('');
    setNewIssueDesc('');
  };

  const getSystemBg = (system: SystemType) => {
    switch (system) {
      case 'HVAC':
        return 'bg-green-500/15 border-green-500 text-green-400';
      case 'Plumbing':
        return 'bg-blue-500/15 border-blue-500 text-blue-400';
      case 'Electrical':
        return 'bg-yellow-500/15 border-yellow-500 text-yellow-400';
      case 'FireProtection':
        return 'bg-red-500/15 border-red-500 text-red-400';
      case 'Structural':
        return 'bg-slate-500/15 border-slate-500 text-slate-300';
    }
  };

  // --- INITIALIZE THREE.JS CORE ENGINE ---
  useEffect(() => {
    if (!canvasRef.current || !containerRef.current) return;

    const width = containerRef.current.clientWidth || 800;
    const height = containerRef.current.clientHeight || 480;

    // 1. Renderer Setup
    const renderer = new THREE.WebGLRenderer({
      canvas: canvasRef.current,
      antialias: true,
      alpha: true,
      powerPreference: 'high-performance',
    });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.shadowMap.enabled = true;

    // 2. Scene Setup
    const scene = new THREE.Scene();
    scene.fog = new THREE.FogExp2(0x070a13, 0.08); // Moody volumetric tunnel look

    // 3. Camera Setup
    const camera = new THREE.PerspectiveCamera(42, width / height, 0.1, 100);
    // Initial camera placement
    camera.position.set(4, 3, 7);

    // 4. Orbit Controls
    const controls = new OrbitControls(camera, renderer.domElement);
    controls.enableDamping = true;
    controls.dampingFactor = 0.05;
    controls.maxPolarAngle = Math.PI / 2 + 0.05; // Lock camera from going below floor level
    controls.minDistance = 2.5;
    controls.maxDistance = 18;
    controls.target.set(0, 0, -3);

    // Camera preset targets for smooth transitions
    const targetCameraPos = new THREE.Vector3(4, 3, 7);
    const targetCameraLook = new THREE.Vector3(0, 0, -3);

    // 5. Lights
    // Ambient light
    const ambientLight = new THREE.AmbientLight(0x0f172a, 1.6);
    scene.add(ambientLight);

    // Directional construction site lights pouring in from side openings
    const dirLight1 = new THREE.DirectionalLight(0xffffff, 2.2);
    dirLight1.position.set(7, 5, 2);
    dirLight1.castShadow = true;
    scene.add(dirLight1);

    const dirLight2 = new THREE.DirectionalLight(0x3b82f6, 1.0); // Blueprint ambient highlight
    dirLight2.position.set(-8, 3, -6);
    scene.add(dirLight2);

    // Point lights representing real-time neon glowing emissions of active MEP networks
    const hvacLight = new THREE.PointLight(0x22c55e, 2, 8);
    hvacLight.position.set(1.4, 1.4, -3);
    const plumbingLight = new THREE.PointLight(0x3b82f6, 2.5, 8);
    plumbingLight.position.set(-2.2, -0.6, -5);
    const electricalLight = new THREE.PointLight(0xeab308, 2, 8);
    electricalLight.position.set(-1.8, 1.1, -2);
    const fireLight = new THREE.PointLight(0xef4444, 2, 8);
    fireLight.position.set(0, 1.8, -4);
    scene.add(hvacLight, plumbingLight, electricalLight, fireLight);

    // 6. Geometry: VIRTUAL RAW CONCRETE SITE TUNNEL
    // Floor (concrete slab)
    const floorGeo = new THREE.BoxGeometry(10, 0.2, 30);
    const floorMat = new THREE.MeshStandardMaterial({ 
      color: 0x141822, 
      roughness: 0.85,
      metalness: 0.1,
    });
    const floor = new THREE.Mesh(floorGeo, floorMat);
    floor.position.y = -2.6;
    scene.add(floor);

    // High-tech holographic floor grid helper
    const gridHelper = new THREE.GridHelper(30, 30, 0x1e3a8a, 0x0f172a);
    gridHelper.position.y = -2.48;
    scene.add(gridHelper);

    // Ceiling slab
    const ceilingGeo = new THREE.BoxGeometry(10, 0.2, 30);
    const ceilingMat = new THREE.MeshStandardMaterial({ 
      color: 0x11141e, 
      roughness: 0.75 
    });
    const ceiling = new THREE.Mesh(ceilingGeo, ceilingMat);
    ceiling.position.y = 2.6;
    scene.add(ceiling);

    // Concrete Pillars (Supports)
    const pillarGeo = new THREE.CylinderGeometry(0.35, 0.35, 5, 12);
    const pillarMat = new THREE.MeshStandardMaterial({ 
      color: 0x1e2433, 
      roughness: 0.9 
    });
    const pillarPositions = [
      { x: -3.2, z: -1 }, { x: -3.2, z: -5 }, { x: -3.2, z: -9 },
      { x: 3.2, z: -3 }, { x: 3.2, z: -7 }, { x: 3.2, z: -11 }
    ];
    pillarPositions.forEach(pos => {
      const pillar = new THREE.Mesh(pillarGeo, pillarMat);
      pillar.position.set(pos.x, 0, pos.z);
      scene.add(pillar);
    });

    // Concrete Over-head Girders
    const girderGeo = new THREE.BoxGeometry(10, 0.5, 0.6);
    const girderZOffsets = [-2, -6, -10];
    girderZOffsets.forEach(z => {
      const girder = new THREE.Mesh(girderGeo, pillarMat);
      girder.position.set(0, 2.35, z);
      scene.add(girder);
    });

    // 7. MEP SYSTEM GEOMETRY GROUPS
    // HVAC (Green ventilation ducts)
    const hvacGroup = new THREE.Group();
    const hvacMat = new THREE.MeshStandardMaterial({
      color: 0x22c55e,
      roughness: 0.4,
      metalness: 0.4,
      emissive: 0x15803d,
      emissiveIntensity: 0.3,
      transparent: true,
      opacity: arOpacity / 100,
    });
    // Main supply duct running straight down on the right ceiling
    const mainDuct = new THREE.Mesh(new THREE.BoxGeometry(1.0, 0.6, 14), hvacMat);
    mainDuct.position.set(1.4, 1.4, -4);
    hvacGroup.add(mainDuct);
    // Leftwards branch duct
    const branchDuct = new THREE.Mesh(new THREE.BoxGeometry(1.8, 0.4, 0.4), hvacMat);
    branchDuct.position.set(0, 1.4, -3);
    hvacGroup.add(branchDuct);
    scene.add(hvacGroup);

    // Plumbing (Blue parallel pipelines)
    const plumbingGroup = new THREE.Group();
    const plumbingMat = new THREE.MeshStandardMaterial({
      color: 0x3b82f6,
      roughness: 0.25,
      metalness: 0.7,
      emissive: 0x1d4ed8,
      emissiveIntensity: 0.3,
      transparent: true,
      opacity: arOpacity / 100,
    });
    // Double lines running parallel on the left side wall
    const pipeGeo = new THREE.CylinderGeometry(0.08, 0.08, 14, 8);
    const pipe1 = new THREE.Mesh(pipeGeo, plumbingMat);
    pipe1.rotation.x = Math.PI / 2;
    pipe1.position.set(-2.2, -0.4, -4);
    const pipe2 = new THREE.Mesh(pipeGeo, plumbingMat);
    pipe2.rotation.x = Math.PI / 2;
    pipe2.position.set(-2.2, -0.7, -4);
    plumbingGroup.add(pipe1, pipe2);
    // Vertical riser drop
    const vertRiser = new THREE.Mesh(new THREE.CylinderGeometry(0.08, 0.08, 2, 8), plumbingMat);
    vertRiser.position.set(-2.2, -1.7, -4);
    plumbingGroup.add(vertRiser);
    scene.add(plumbingGroup);

    // Electrical Cable Trays & Wire Bundles (Yellow)
    const electricalGroup = new THREE.Group();
    const eleMat = new THREE.MeshStandardMaterial({
      color: 0xeab308,
      roughness: 0.5,
      metalness: 0.5,
      emissive: 0xa16207,
      emissiveIntensity: 0.2,
      transparent: true,
      opacity: arOpacity / 100,
    });
    // Build a nice cable ladder (left side, slightly overhead)
    const trayLeftBar = new THREE.Mesh(new THREE.BoxGeometry(0.03, 0.08, 14), eleMat);
    trayLeftBar.position.set(-1.8, 1.1, -4);
    const trayRightBar = new THREE.Mesh(new THREE.BoxGeometry(0.03, 0.08, 14), eleMat);
    trayRightBar.position.set(-1.4, 1.1, -4);
    electricalGroup.add(trayLeftBar, trayRightBar);
    // Ladder steps
    for (let z = -10; z <= 2; z += 1.2) {
      const step = new THREE.Mesh(new THREE.BoxGeometry(0.4, 0.01, 0.03), eleMat);
      step.position.set(-1.6, 1.08, z);
      electricalGroup.add(step);
    }
    // Colorful thick electrical conduits lying inside
    const cableMat1 = new THREE.MeshStandardMaterial({ color: 0xd97706, roughness: 0.6 });
    const cableMat2 = new THREE.MeshStandardMaterial({ color: 0xeab308, roughness: 0.6 });
    const cableGeo = new THREE.CylinderGeometry(0.02, 0.02, 14, 6);
    const c1 = new THREE.Mesh(cableGeo, cableMat1);
    c1.rotation.x = Math.PI / 2;
    c1.position.set(-1.5, 1.12, -4);
    const c2 = new THREE.Mesh(cableGeo, cableMat2);
    c2.rotation.x = Math.PI / 2;
    c2.position.set(-1.7, 1.12, -4);
    electricalGroup.add(c1, c2);
    scene.add(electricalGroup);

    // Fire Protection lines (Red pipes + Sprinklers)
    const fireGroup = new THREE.Group();
    const fireMat = new THREE.MeshStandardMaterial({
      color: 0xef4444,
      roughness: 0.3,
      metalness: 0.5,
      emissive: 0x991b1b,
      emissiveIntensity: 0.4,
      transparent: true,
      opacity: arOpacity / 100,
    });
    // Main tube hanging down the exact ceiling center
    const firePipe = new THREE.Mesh(new THREE.CylinderGeometry(0.04, 0.04, 14, 8), fireMat);
    firePipe.rotation.x = Math.PI / 2;
    firePipe.position.set(0, 1.8, -4);
    fireGroup.add(firePipe);
    // Hanging sprinkler droppers
    const zDrops = [-1, -4, -7, -10];
    zDrops.forEach(z => {
      const drop = new THREE.Mesh(new THREE.CylinderGeometry(0.02, 0.02, 0.3, 6), fireMat);
      drop.position.set(0, 1.65, z);
      const nozzle = new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.03, 0.08, 6), fireMat);
      nozzle.position.set(0, 1.5, z);
      fireGroup.add(drop, nozzle);
    });
    scene.add(fireGroup);

    // 8. Interactive 3D Pin Container
    const pinGroup = new THREE.Group();
    scene.add(pinGroup);

    // Save Three.js object references for reactivity and frame loops
    threeEngineRef.current = {
      scene,
      camera,
      renderer,
      controls,
      hvacGroup,
      plumbingGroup,
      electricalGroup,
      fireGroup,
      pinGroup,
      targetCameraPos,
      targetCameraLook,
    };

    // 9. ANIMATION LOOP
    let time = 0;
    let animationFrameId: number;

    const animate = () => {
      animationFrameId = requestAnimationFrame(animate);
      time += 0.02;

      const engine = threeEngineRef.current;
      if (!engine) return;

      const { camera: cam, controls: ctrl, hvacGroup: h, plumbingGroup: p, electricalGroup: el, fireGroup: f } = engine;

      // Smooth camera transition towards current preset target
      cam.position.lerp(engine.targetCameraPos, 0.06);
      ctrl.target.lerp(engine.targetCameraLook, 0.06);

      // Pulse neon point lights in response to selection
      hvacLight.intensity = selectedSystems.HVAC ? 2.5 + Math.sin(time * 3) * 0.4 : 0;
      plumbingLight.intensity = selectedSystems.Plumbing ? 2.5 + Math.sin(time * 4) * 0.4 : 0;
      electricalLight.intensity = selectedSystems.Electrical ? 2.0 + Math.sin(time * 2.5) * 0.3 : 0;
      fireLight.intensity = selectedSystems.FireProtection ? 2.5 + Math.sin(time * 5) * 0.5 : 0;

      // Animate active 3D markers (pins)
      engine.pinGroup.children.forEach((pinGroupObj) => {
        // Octahedron core rotation
        if (pinGroupObj.children[0]) {
          pinGroupObj.children[0].rotation.y += 0.025;
          pinGroupObj.children[0].rotation.z += 0.01;
        }
        // Outer glowing torus ring reverse spin and pulse scale
        if (pinGroupObj.children[1]) {
          pinGroupObj.children[1].rotation.z -= 0.015;
          const scalePulse = 1.0 + Math.sin(time * 4) * 0.12;
          pinGroupObj.children[1].scale.set(scalePulse, scalePulse, scalePulse);
        }
      });

      ctrl.update();
      renderer.render(scene, cam);

      // Projected HTML HUD Marker placement tracker
      updateHUDMarkerProjections();
    };

    // Tracks and updates positions of standard absolute 2D overlay hotspots in tandem with 3D camera matrices
    const updateHUDMarkerProjections = () => {
      const engine = threeEngineRef.current;
      if (!engine || !containerRef.current) return;

      const { camera: cam } = engine;

      const hotspotElements = containerRef.current.querySelectorAll('[data-hotspot-id]');
      hotspotElements.forEach((el) => {
        const htmlElement = el as HTMLElement;
        const id = htmlElement.getAttribute('data-hotspot-id');
        if (!id) return;

        // Get matching 3D coordinate
        let pos3D: THREE.Vector3 | null = null;
        if (id.startsWith('elem-')) {
          const match = PRESET_ELEMENTS.find(e => e.id === id);
          if (match) pos3D = get3DPosition(match.coordinates.x, match.coordinates.y);
        } else if (id.startsWith('issue-')) {
          const match = issues.find(i => i.id === id);
          if (match && match.coordinateX !== undefined && match.coordinateY !== undefined) {
            pos3D = get3DPosition(match.coordinateX, match.coordinateY);
          }
        }

        if (pos3D) {
          // Project 3D vector to normalized device coordinates (NDC)
          const tempVec = pos3D.clone();
          tempVec.project(cam);

          // If coordinate is behind the camera near plane, hide the marker
          if (tempVec.z > 1) {
            htmlElement.style.display = 'none';
          } else {
            htmlElement.style.display = 'block';
            // Map NDC coordinates to 0%-100% container margins
            const px = (tempVec.x * 0.5 + 0.5) * 100;
            const py = (-tempVec.y * 0.5 + 0.5) * 100;

            htmlElement.style.left = `${px}%`;
            htmlElement.style.top = `${py}%`;
          }
        }
      });
    };

    // 10. Start rendering loop
    animate();

    // 11. Handle container size alterations
    const resizeObserver = new ResizeObserver((entries) => {
      for (let entry of entries) {
        const { width: w, height: h } = entry.contentRect;
        if (w && h) {
          renderer.setSize(w, h);
          camera.aspect = w / h;
          camera.updateProjectionMatrix();
        }
      }
    });
    resizeObserver.observe(containerRef.current);

    // 12. DISPOSE ENGINE ON UNMOUNT
    return () => {
      cancelAnimationFrame(animationFrameId);
      resizeObserver.disconnect();
      renderer.dispose();
      floorGeo.dispose();
      floorMat.dispose();
      ceilingGeo.dispose();
      ceilingMat.dispose();
      pillarGeo.dispose();
      pillarMat.dispose();
      girderGeo.dispose();
      hvacMat.dispose();
      plumbingMat.dispose();
      eleMat.dispose();
      fireMat.dispose();
      controls.dispose();
    };
  }, []);

  // --- REACT TO SLIDERS, SYSTEM VISIBILITY TOGGLES, AND DISCREPANCY REGISTER UPDATES ---
  useEffect(() => {
    const engine = threeEngineRef.current;
    if (!engine) return;

    // A. Toggle visibilities of 3D system groups
    engine.hvacGroup.visible = selectedSystems.HVAC;
    engine.plumbingGroup.visible = selectedSystems.Plumbing;
    engine.electricalGroup.visible = selectedSystems.Electrical;
    engine.fireGroup.visible = selectedSystems.FireProtection;

    // B. Apply opacity slider dynamically to all digital overlays
    const applyOpacity = (group: THREE.Group) => {
      group.traverse((node) => {
        if (node instanceof THREE.Mesh && node.material) {
          const mats = Array.isArray(node.material) ? node.material : [node.material];
          mats.forEach((mat) => {
            if (mat instanceof THREE.MeshStandardMaterial) {
              mat.transparent = true;
              mat.opacity = arOpacity / 100;
              mat.needsUpdate = true;
            }
          });
        }
      });
    };

    applyOpacity(engine.hvacGroup);
    applyOpacity(engine.plumbingGroup);
    applyOpacity(engine.electricalGroup);
    applyOpacity(engine.fireGroup);

    // C. DYNAMICALLY REBUILD 3D HOTSPOT PINS
    const { pinGroup, scene } = engine;
    
    // Wipe clean old physical 3D pins
    while (pinGroup.children.length > 0) {
      const pinObj = pinGroup.children[0];
      pinGroup.remove(pinObj);
    }

    // Insert updated pins
    issues.forEach((issue) => {
      if (issue.coordinateX === undefined || issue.coordinateY === undefined) return;
      if (!selectedSystems[issue.system]) return;

      const isSelected = selectedIssueId === issue.id;
      const pos3D = get3DPosition(issue.coordinateX, issue.coordinateY);

      // Create a local group for this specific pin (Octahedron + Torus Ring)
      const pinSubGroup = new THREE.Group();
      pinSubGroup.position.copy(pos3D);
      pinSubGroup.name = `pin-${issue.id}`;

      // Core: High-tech floating octahedron diamond
      const sizeFactor = isSelected ? 1.35 : 1.0;
      const coreGeo = new THREE.OctahedronGeometry(0.18 * sizeFactor, 0);
      const coreMat = new THREE.MeshStandardMaterial({
        color: isSelected ? 0xef4444 : 0xf59e0b, // Red for active selected, orange-amber for normal
        emissive: isSelected ? 0xd01c1c : 0xd97706,
        emissiveIntensity: 0.8,
        metalness: 0.7,
        roughness: 0.2,
      });
      const coreMesh = new THREE.Mesh(coreGeo, coreMat);
      pinSubGroup.add(coreMesh);

      // Outer: spinning holographic halo ring
      const ringGeo = new THREE.TorusGeometry(0.24 * sizeFactor, 0.02, 8, 16);
      const ringMat = new THREE.MeshBasicMaterial({
        color: isSelected ? 0xfc8181 : 0xfcd34d,
        transparent: true,
        opacity: 0.75,
      });
      const ringMesh = new THREE.Mesh(ringGeo, ringMat);
      ringMesh.rotation.x = Math.PI / 2;
      pinSubGroup.add(ringMesh);

      pinGroup.add(pinSubGroup);
    });

  }, [selectedSystems, arOpacity, issues, selectedIssueId]);

  return (
    <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
      {/* Sidebar Control Panel */}
      <div className="lg:col-span-1 bg-slate-900/60 backdrop-blur-md p-5 rounded-2xl border border-slate-800 flex flex-col justify-between shadow-lg">
        <div>
          <div className="flex items-center gap-2 mb-4">
            <Layers className="w-5 h-5 text-blue-400" />
            <h3 className="font-display font-semibold text-lg text-white">Contrôle AR & 3D</h3>
          </div>

          <p className="text-xs text-slate-400 mb-6 leading-relaxed">
            Manipulez la maquette 3D interactive MEP ci-contre en faisant pivoter, zoomer et filtrer les couches techniques en temps réel.
          </p>

          {/* Opacity Slider */}
          <div className="mb-6">
            <div className="flex justify-between items-center mb-2">
              <span className="text-xs font-medium text-slate-300 flex items-center gap-1.5">
                <Sliders className="w-3.5 h-3.5 text-blue-400" />
                Intensité des hologrammes (RA)
              </span>
              <span className="text-xs font-mono font-bold text-blue-400">{arOpacity}%</span>
            </div>
            <input
              type="range"
              min="0"
              max="100"
              value={arOpacity}
              onChange={(e) => setArOpacity(parseInt(e.target.value))}
              className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-blue-500 transition-all"
            />
            <div className="flex justify-between text-[10px] text-slate-500 mt-1">
              <span>Chantier réel (Nu)</span>
              <span>Fusion AR</span>
              <span>Hologramme Pur</span>
            </div>
          </div>

          {/* MEP Filters */}
          <div className="mb-6">
            <span className="text-xs font-medium text-slate-300 block mb-3">Réseaux Techniques</span>
            <div className="space-y-2">
              {(['HVAC', 'Plumbing', 'Electrical', 'FireProtection'] as SystemType[]).map((sys) => {
                const isSelected = selectedSystems[sys];
                const sysLabels: Record<SystemType, string> = {
                  HVAC: 'Ventilation & Climatisation',
                  Plumbing: 'Plomberie & Fluides',
                  Electrical: 'Électricité & Câblages',
                  FireProtection: 'Sécurité Incendie',
                  Structural: 'Structure Béton/Métal',
                };
                const colorMap: Record<SystemType, string> = {
                  HVAC: 'border-green-500/40 text-green-400 bg-green-500/10 hover:bg-green-500/20',
                  Plumbing: 'border-blue-500/40 text-blue-400 bg-blue-500/10 hover:bg-blue-500/20',
                  Electrical: 'border-yellow-500/40 text-yellow-400 bg-yellow-500/10 hover:bg-yellow-500/20',
                  FireProtection: 'border-red-500/40 text-red-400 bg-red-500/10 hover:bg-red-500/20',
                  Structural: 'border-slate-500/40 text-slate-400 bg-slate-500/10 hover:bg-slate-500/20',
                };

                return (
                  <button
                    key={sys}
                    onClick={() => toggleSystem(sys)}
                    className={`w-full text-left p-2.5 rounded-xl text-xs font-medium border transition-all flex items-center justify-between ${
                      isSelected
                        ? `${colorMap[sys]} shadow-[0_0_12px_rgba(30,41,59,0.3)] font-semibold`
                        : 'border-slate-800 text-slate-500 bg-slate-950/40 hover:border-slate-700'
                    }`}
                  >
                    <span>{sysLabels[sys]}</span>
                    {isSelected ? (
                      <Eye className="w-3.5 h-3.5" />
                    ) : (
                      <EyeOff className="w-3.5 h-3.5 text-slate-600" />
                    )}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Quick Camera Presets Layout */}
          <div className="mb-6">
            <span className="text-xs font-medium text-slate-300 block mb-2.5">Angles de caméra 3D</span>
            <div className="grid grid-cols-2 gap-2">
              <button
                onClick={() => applyCameraPreset('global')}
                className={`p-2 rounded-xl text-[10px] font-semibold border flex flex-col items-center gap-1.5 transition-all ${
                  activePreset === 'global'
                    ? 'bg-blue-600/20 border-blue-500 text-blue-400'
                    : 'bg-slate-950/40 border-slate-800 text-slate-400 hover:border-slate-750'
                }`}
              >
                <Compass className="w-3.5 h-3.5" />
                Persp. Globale
              </button>
              <button
                onClick={() => applyCameraPreset('front')}
                className={`p-2 rounded-xl text-[10px] font-semibold border flex flex-col items-center gap-1.5 transition-all ${
                  activePreset === 'front'
                    ? 'bg-blue-600/20 border-blue-500 text-blue-400'
                    : 'bg-slate-950/40 border-slate-800 text-slate-400 hover:border-slate-750'
                }`}
              >
                <Video className="w-3.5 h-3.5" />
                Alignement Face
              </button>
              <button
                onClick={() => applyCameraPreset('ceiling')}
                className={`p-2 rounded-xl text-[10px] font-semibold border flex flex-col items-center gap-1.5 transition-all ${
                  activePreset === 'ceiling'
                    ? 'bg-blue-600/20 border-blue-500 text-blue-400'
                    : 'bg-slate-950/40 border-slate-800 text-slate-400 hover:border-slate-750'
                }`}
              >
                <Box className="w-3.5 h-3.5" />
                Coupe Plafond
              </button>
              <button
                onClick={() => applyCameraPreset('piping')}
                className={`p-2 rounded-xl text-[10px] font-semibold border flex flex-col items-center gap-1.5 transition-all ${
                  activePreset === 'piping'
                    ? 'bg-blue-600/20 border-blue-500 text-blue-400'
                    : 'bg-slate-950/40 border-slate-800 text-slate-400 hover:border-slate-750'
                }`}
              >
                <Rotate3d className="w-3.5 h-3.5" />
                Canalisations
              </button>
            </div>
          </div>

          {/* Action Button: Discrepancy mode */}
          <button
            onClick={() => {
              setIsAddingIssueMode(!isAddingIssueMode);
              setClickCoordinates(null);
            }}
            className={`w-full py-3 px-4 rounded-xl text-xs font-semibold flex items-center justify-center gap-2 transition-all ${
              isAddingIssueMode
                ? 'bg-red-500 hover:bg-red-600 text-white shadow-lg shadow-red-500/20'
                : 'bg-blue-600 hover:bg-blue-700 text-white shadow-lg shadow-blue-500/20'
            }`}
          >
            {isAddingIssueMode ? (
              <>
                <Eye className="w-4 h-4" />
                Mode Visualisation 3D
              </>
            ) : (
              <>
                <Plus className="w-4 h-4" />
                Signaler un Écart (RA)
              </>
            )}
          </button>
        </div>

        {/* Dynamic Tip Helper */}
        <div className="mt-6 p-3 bg-slate-950/60 rounded-xl border border-slate-800/80">
          <div className="flex gap-2 items-start">
            <Smartphone className="w-4 h-4 text-blue-400 shrink-0 mt-0.5" />
            <p className="text-[10px] text-slate-400 leading-relaxed">
              {isAddingIssueMode
                ? "Activez l'écartement 3D : Cliquez directement n'importe où dans le tunnel 3D pour placer une broche d'écart physique par rapport à la maquette."
                : 'Pivotez librement la scène 3D avec le bouton gauche. Utilisez la molette pour zoomer, et le bouton droit pour faire un panoramique.'}
            </p>
          </div>
        </div>
      </div>

      {/* Main Interactive AR Viewer Canvas */}
      <div className="lg:col-span-3 flex flex-col gap-4">
        <div className="relative overflow-hidden rounded-2xl border border-slate-800 bg-slate-950 h-[480px] select-none shadow-2xl">
          {/* WebGL 3D Canvas Viewport */}
          <div
            id="ar-viewport"
            ref={containerRef}
            onClick={handleCanvasClick}
            className={`absolute inset-0 transition-all duration-300 w-full h-full ${
              isAddingIssueMode ? 'cursor-cell ring-2 ring-red-500/60 bg-red-500/[0.01]' : 'cursor-grab active:cursor-grabbing'
            }`}
          >
            {/* Real WebGL Canvas */}
            <canvas ref={canvasRef} className="absolute inset-0 w-full h-full block" />

            {/* Subtle high-tech scanline screen overlay for futuristic HUD style */}
            <div className="absolute inset-0 bg-[linear-gradient(rgba(18,24,38,0)_97%,rgba(59,130,246,0.03)_97%)] bg-[length:100%_4px] pointer-events-none" />

            {/* Glowing peripheral frame vignette */}
            <div className="absolute inset-0 bg-radial-vignette pointer-events-none" />

            {/* AR Overlay HUD Graphics Header */}
            <div className="absolute top-4 left-4 right-4 flex items-center justify-between pointer-events-none">
              <div className="flex items-center gap-2 bg-slate-900/85 backdrop-blur-md border border-slate-800/80 rounded-lg px-3 py-1.5 text-[10px] font-mono text-slate-300">
                <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
                <span>MAQUETTE BIM NUMÉRIQUE : MODÈLE MEP 3D ACTIF</span>
              </div>
              
              <div className="flex items-center gap-2 bg-slate-900/85 backdrop-blur-md border border-slate-800/80 rounded-lg px-3 py-1.5 text-[10px] font-mono text-blue-400">
                <Rotate3d className="w-3.5 h-3.5 animate-spin-slow text-blue-500" />
                <span>MOTEUR RENDU INTERACTIF WEBGL</span>
              </div>
            </div>

            {/* ---------------- PROJECTED 2D HUD HOTSPOTS ON TOP OF 3D SPACE ---------------- */}
            {/* 1. BIM Elements Hotspots (Only visible if arOpacity allows) */}
            {arOpacity > 10 &&
              PRESET_ELEMENTS.map((elem) => {
                if (!selectedSystems[elem.system]) return null;
                const isInspecting = inspectingElement?.id === elem.id;

                return (
                  <button
                    key={elem.id}
                    data-hotspot-id={elem.id}
                    onClick={(e) => {
                      e.stopPropagation();
                      setInspectingElement(isInspecting ? null : elem);
                    }}
                    className="absolute group z-20 transform -translate-x-1/2 -translate-y-1/2 transition-transform duration-100 ease-out"
                    style={{ left: '50%', top: '50%', display: 'none' }} // Positions set dynamically in Three.js animation frame
                  >
                    {/* Ring aura indicator */}
                    <span className="absolute -inset-3.5 rounded-full border border-white/40 opacity-0 group-hover:opacity-100 group-hover:scale-110 transition-all duration-300 pointer-events-none"></span>
                    
                    <div
                      className={`w-6 h-6 rounded-full flex items-center justify-center border-2 border-white/90 shadow-[0_0_12px_rgba(255,255,255,0.45)] transition-all ${
                        isInspecting
                          ? 'scale-125 bg-white text-slate-900'
                          : elem.status === 'Écart Détecté'
                          ? 'bg-amber-500 text-white animate-pulse'
                          : 'bg-blue-600 text-white hover:bg-blue-500'
                      }`}
                    >
                      {elem.status === 'Écart Détecté' ? (
                        <AlertTriangle className="w-3.5 h-3.5" />
                      ) : (
                        <Info className="w-3.5 h-3.5" />
                      )}
                    </div>

                    {/* Holographic specs label hovering on marker hover */}
                    <div className="absolute left-1/2 bottom-8 -translate-x-1/2 bg-slate-950/95 border border-slate-700/80 p-2.5 rounded-xl text-[10px] text-white w-48 opacity-0 group-hover:opacity-100 transition-opacity duration-200 pointer-events-none shadow-2xl z-50 backdrop-blur-md">
                      <div className="font-semibold truncate mb-0.5 border-b border-slate-800 pb-1 text-slate-100">{elem.name}</div>
                      <div className="text-slate-400 flex justify-between mt-1">
                        <span>Système :</span>
                        <span className="font-semibold text-blue-400">{elem.system}</span>
                      </div>
                      <div className="text-slate-400 flex justify-between">
                        <span>Altitude :</span>
                        <span>{elem.elevation}</span>
                      </div>
                      <div className="mt-1.5 flex items-center gap-1.5">
                        <span
                          className={`w-1.5 h-1.5 rounded-full ${
                            elem.status === 'Conforme' ? 'bg-emerald-500' : 'bg-amber-500'
                          }`}
                        ></span>
                        <span className={elem.status === 'Conforme' ? 'text-emerald-400 font-bold' : 'text-amber-400 font-bold'}>
                          {elem.status}
                        </span>
                      </div>
                    </div>
                  </button>
                );
              })}

            {/* 2. Registered Active Site Issues Indicators (projected in 3D) */}
            {issues.map((issue) => {
              if (issue.coordinateX === undefined || issue.coordinateY === undefined) return null;
              if (!selectedSystems[issue.system]) return null;

              const isSelected = selectedIssueId === issue.id;

              return (
                <button
                  key={issue.id}
                  data-hotspot-id={issue.id}
                  onClick={(e) => {
                    e.stopPropagation();
                    onSelectIssue(isSelected ? null : issue.id);
                  }}
                  className="absolute group z-30 transform -translate-x-1/2 -translate-y-1/2 transition-transform duration-100 ease-out"
                  style={{ left: '50%', top: '50%', display: 'none' }} // Positions calculated in frame loop
                >
                  <span className="absolute -inset-3.5 rounded-full border-2 border-red-500/60 animate-ping pointer-events-none" style={{ animationDuration: '3s' }}></span>
                  <div
                    className={`w-7 h-7 rounded-full flex items-center justify-center border-2 border-red-500 text-white transition-all shadow-[0_0_15px_rgba(239,68,68,0.6)] ${
                      isSelected ? 'bg-red-500 scale-125' : 'bg-red-600/90 hover:bg-red-500'
                    }`}
                  >
                    <AlertTriangle className="w-4 h-4" />
                  </div>

                  {/* Projected HUD floating callout label */}
                  <div className="absolute left-8 top-1/2 -translate-y-1/2 bg-red-600/90 backdrop-blur-md border border-red-400/40 px-2 py-1 rounded text-[10px] font-semibold whitespace-nowrap shadow-xl text-white">
                    {issue.title}
                  </div>
                </button>
              );
            })}

            {/* Instructions Overlay in Creation Mode */}
            {isAddingIssueMode && !clickCoordinates && (
              <div className="absolute inset-0 bg-red-500/[0.04] backdrop-blur-[0.5px] flex items-center justify-center pointer-events-none z-10">
                <div className="bg-slate-900/95 border border-red-500/50 p-4 rounded-xl text-center shadow-2xl max-w-xs backdrop-blur-md">
                  <AlertTriangle className="w-8 h-8 text-red-500 mx-auto mb-2 animate-bounce" />
                  <h4 className="font-semibold text-xs text-white uppercase tracking-wider mb-1">
                    Ajouter un Écart 3D (RA)
                  </h4>
                  <p className="text-[10px] text-slate-300 leading-relaxed">
                    Cliquez directement n'importe où sur l'espace 3D du tunnel pour épingler le point d'écart observé.
                  </p>
                </div>
              </div>
            )}

            {/* Discrepancy Placement Pin Indicator */}
            {clickCoordinates && (
              <div
                className="absolute z-40 transform -translate-x-1/2 -translate-y-1/2"
                style={{ left: `${clickCoordinates.x}%`, top: `${clickCoordinates.y}%` }}
              >
                <div className="w-8 h-8 rounded-full bg-amber-500 flex items-center justify-center border-2 border-white animate-bounce text-slate-900 shadow-xl">
                  <Plus className="w-5 h-5 font-bold" />
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Dynamic Detail Card Panels: Element Inspector or Custom Form */}
        <AnimatePresence mode="wait">
          {clickCoordinates && (
            <motion.div
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              className="bg-slate-900/90 border border-amber-500/40 p-5 rounded-2xl shadow-xl backdrop-blur-md"
            >
              <div className="flex justify-between items-center mb-4">
                <h4 className="font-display font-bold text-sm text-amber-400 flex items-center gap-2">
                  <AlertTriangle className="w-4 h-4" />
                  Nouvel Écart détecté au point ({clickCoordinates.x}%, {clickCoordinates.y}%)
                </h4>
                <button onClick={cancelAddingIssue} className="text-slate-400 hover:text-white text-xs transition-colors">
                  Annuler
                </button>
              </div>

              <form onSubmit={handleCreateIssueSubmit} className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="md:col-span-1">
                  <label className="block text-[10px] uppercase font-bold text-slate-400 mb-1">
                    Titre du problème *
                  </label>
                  <input
                    type="text"
                    required
                    value={newIssueTitle}
                    onChange={(e) => setNewIssueTitle(e.target.value)}
                    placeholder="ex: Collision gaine HVAC / Poutre"
                    className="w-full text-xs bg-slate-950 border border-slate-850 rounded-lg px-3 py-2 text-white focus:outline-none focus:border-amber-500"
                  />
                </div>

                <div className="md:col-span-1">
                  <label className="block text-[10px] uppercase font-bold text-slate-400 mb-1">
                    Réseau Technique affecté
                  </label>
                  <select
                    value={newIssueSystem}
                    onChange={(e) => setNewIssueSystem(e.target.value as SystemType)}
                    className="w-full text-xs bg-slate-950 border border-slate-850 rounded-lg px-3 py-2 text-white focus:outline-none focus:border-amber-500"
                  >
                    <option value="HVAC">HVAC / Ventilation</option>
                    <option value="Plumbing">Plomberie & Fluides</option>
                    <option value="Electrical">Électricité</option>
                    <option value="FireProtection">Sécurité Incendie</option>
                  </select>
                </div>

                <div className="md:col-span-1">
                  <label className="block text-[10px] uppercase font-bold text-slate-400 mb-1">
                    Niveau de Priorité
                  </label>
                  <select
                    value={newIssuePriority}
                    onChange={(e) => setNewIssuePriority(e.target.value as 'Haute' | 'Moyenne' | 'Basse')}
                    className="w-full text-xs bg-slate-950 border border-slate-850 rounded-lg px-3 py-2 text-white focus:outline-none focus:border-amber-500"
                  >
                    <option value="Basse">Basse (Simple écart d'alignement)</option>
                    <option value="Moyenne">Moyenne (Entrave mineure)</option>
                    <option value="Haute">Haute (Blocage chantier/Clash)</option>
                  </select>
                </div>

                <div className="md:col-span-3">
                  <label className="block text-[10px] uppercase font-bold text-slate-400 mb-1">
                    Description détaillée de la non-conformité
                  </label>
                  <textarea
                    value={newIssueDesc}
                    onChange={(e) => setNewIssueDesc(e.target.value)}
                    placeholder="Décrivez précisément ce qui ne va pas (ex: le raccord de plomberie a été décalé de 15cm vers la gauche pour éviter un poteau non répertorié sur la maquette)."
                    className="w-full text-xs bg-slate-950 border border-slate-850 rounded-lg px-3 py-2 text-white focus:outline-none focus:border-amber-500 h-16 resize-none"
                  ></textarea>
                </div>

                <div className="md:col-span-3 flex justify-end gap-2.5 mt-2">
                  <button
                    type="button"
                    onClick={cancelAddingIssue}
                    className="px-4 py-2 bg-slate-800 hover:bg-slate-750 text-xs font-semibold text-slate-300 rounded-lg transition-colors"
                  >
                    Annuler
                  </button>
                  <button
                    type="submit"
                    className="px-4 py-2 bg-amber-500 hover:bg-amber-600 text-xs font-semibold text-slate-950 rounded-lg flex items-center gap-1.5 transition-colors"
                  >
                    <CheckCircle className="w-4 h-4" />
                    Enregistrer l'écart sur site
                  </button>
                </div>
              </form>
            </motion.div>
          )}

          {inspectingElement && !clickCoordinates && (
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="bg-slate-900 border border-slate-800 p-5 rounded-2xl flex flex-col md:flex-row gap-5 justify-between items-start"
            >
              <div className="flex-1">
                <div className="flex items-center gap-2 mb-2">
                  <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase border ${getSystemBg(inspectingElement.system)}`}>
                    {inspectingElement.system}
                  </span>
                  <span className="text-xs text-slate-500 font-mono">ID Maquette: {inspectingElement.id}</span>
                </div>
                <h4 className="font-display font-bold text-base text-white mb-2">{inspectingElement.name}</h4>
                
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-4">
                  <div>
                    <span className="text-[10px] uppercase font-bold text-slate-500 block">Matériau</span>
                    <span className="text-xs text-slate-300">{inspectingElement.material}</span>
                  </div>
                  <div>
                    <span className="text-[10px] uppercase font-bold text-slate-500 block">Altitude/Niveau</span>
                    <span className="text-xs text-slate-300">{inspectingElement.elevation}</span>
                  </div>
                  {inspectingElement.diameter && (
                    <div>
                      <span className="text-[10px] uppercase font-bold text-slate-500 block">Dimension/Diamètre</span>
                      <span className="text-xs text-slate-300">{inspectingElement.diameter}</span>
                    </div>
                  )}
                  {inspectingElement.flowRate && (
                    <div>
                      <span className="text-[10px] uppercase font-bold text-slate-500 block">Débit nominal</span>
                      <span className="text-xs text-slate-300">{inspectingElement.flowRate}</span>
                    </div>
                  )}
                  {inspectingElement.voltage && (
                    <div>
                      <span className="text-[10px] uppercase font-bold text-slate-500 block">Tension réseau</span>
                      <span className="text-xs text-slate-300">{inspectingElement.voltage}</span>
                    </div>
                  )}
                </div>
              </div>

              <div className="flex flex-col gap-2 min-w-[200px] items-stretch self-stretch md:self-auto justify-center">
                <div className="p-3 bg-slate-950/60 rounded-xl border border-slate-800 text-center">
                  <span className="text-[10px] text-slate-500 block mb-1">STATUT DE CONFORMITÉ</span>
                  <div className="flex items-center justify-center gap-1.5">
                    <span className={`w-2 h-2 rounded-full ${inspectingElement.status === 'Conforme' ? 'bg-emerald-500' : 'bg-amber-500 animate-pulse'}`}></span>
                    <span className={`text-xs font-bold ${inspectingElement.status === 'Conforme' ? 'text-emerald-400' : 'text-amber-400'}`}>
                      {inspectingElement.status === 'Conforme' ? 'CONFORME À LA MAQUETTE' : 'ÉCART CHANTIER DÉTECTÉ'}
                    </span>
                  </div>
                </div>
                {inspectingElement.status === 'Écart Détecté' && (
                  <button
                    onClick={() => {
                      setClickCoordinates(inspectingElement.coordinates);
                      setNewIssueTitle(`Écart d'alignement - ${inspectingElement.name}`);
                      setNewIssueSystem(inspectingElement.system);
                      setNewIssueDesc(`L'élément de plomberie ${inspectingElement.name} installé sur le chantier ne correspond pas aux coordonnées BIM théoriques (+2.85m). Détection d'un écart physique d'environ 12cm.`);
                    }}
                    className="w-full py-1.5 px-3 bg-amber-500 hover:bg-amber-600 text-slate-950 rounded-lg text-[11px] font-bold text-center transition-colors"
                  >
                    Ouvrir la fiche d'écart
                  </button>
                )}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
