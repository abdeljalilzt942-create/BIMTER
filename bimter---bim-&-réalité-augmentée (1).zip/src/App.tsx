import React, { useState } from 'react';
import {
  Layers,
  Smartphone,
  Eye,
  CheckCircle,
  AlertTriangle,
  Users,
  Compass,
  FileCheck,
  TrendingDown,
  ChevronRight,
  Monitor,
  CloudLightning,
  Laptop,
  ArrowRight,
  Info,
  Calendar,
  Sparkles,
  PhoneCall,
  Menu,
  X,
  Send,
} from 'lucide-react';
import { SiteIssue, MockModel } from './types';
import ARSimulator from './components/ARSimulator';
import IFCSync from './components/IFCSync';
import IssuesLog from './components/IssuesLog';
import { motion } from 'motion/react';

// Initial preloaded list of site issues/écarts
const INITIAL_ISSUES: SiteIssue[] = [
  {
    id: 'issue-101',
    title: 'Déplacement Collecteur Fluides',
    system: 'Plumbing',
    priority: 'Haute',
    status: 'Nouveau',
    elementName: 'Collecteur Eau Froide Générale (PL-EF-012)',
    location: 'Niveau 2 - Zone Centrale (Travée C3)',
    reportedBy: 'Marc G. (Coordinateur MEP)',
    date: '12/07/2026',
    description: 'Le collecteur d\'eau froide générale a été suspendu 15cm trop bas par rapport aux indications d\'altitude théoriques de la maquette d\'exécution IFC. Cela bloque l\'espace réservé au tracé du chemin de câbles électriques haute tension.',
    coordinateX: 35,
    coordinateY: 52,
  },
  {
    id: 'issue-102',
    title: 'Écart de centrage Gaine HVAC',
    system: 'HVAC',
    priority: 'Moyenne',
    status: 'En cours',
    elementName: 'Gaine de Ventilation Primaire (HVAC-SUP-04)',
    location: 'Niveau 2 - Zone Ouest (Entrée)',
    reportedBy: 'Sarah L. (Chef de lot Climatisation)',
    date: '14/07/2026',
    description: 'Décalage latéral de 8cm vers la gauche de la gaine de soufflage principale. Le raccordement flexible prévu pour le diffuseur terminal est tendu à l\'extrême et risque de se déchirer sous la pression de soufflage.',
    coordinateX: 68,
    coordinateY: 16,
  },
  {
    id: 'issue-103',
    title: 'Gabarit de perçage non respecté',
    system: 'Structural',
    priority: 'Basse',
    status: 'Résolu',
    elementName: 'Poteau Béton Structurel C2',
    location: 'Niveau 1 - Zone Parking',
    reportedBy: 'A. Dufour (Ingénieur Structure)',
    date: '10/07/2026',
    description: 'Les réservations de carottage de passage des tuyaux d\'incendie ont été réalisées avec un écart de 3cm. Après étude d\'impact, la déviation a été acceptée et enregistrée comme conforme par le bureau de contrôle.',
  },
];

export default function App() {
  const [issues, setIssues] = useState<SiteIssue[]>(INITIAL_ISSUES);
  const [selectedIssueId, setSelectedIssueId] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<'ar' | 'sync' | 'log'>('ar');
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [contactFormSubmitted, setContactFormSubmitted] = useState(false);

  // Form states for discovery modal/form
  const [clientName, setClientName] = useState('');
  const [clientEmail, setClientEmail] = useState('');
  const [clientPhone, setClientPhone] = useState('');
  const [clientProject, setClientProject] = useState('Hospitalier');

  const handleAddIssue = (newIssue: SiteIssue) => {
    setIssues((prev) => [newIssue, ...prev]);
  };

  const handleResolveIssue = (id: string) => {
    setIssues((prev) =>
      prev.map((issue) => (issue.id === id ? { ...issue, status: 'Résolu' } : issue))
    );
  };

  const handleDeleteIssue = (id: string) => {
    setIssues((prev) => prev.filter((issue) => issue.id !== id));
    if (selectedIssueId === id) {
      setSelectedIssueId(null);
    }
  };

  const handleModelLoaded = (model: MockModel) => {
    // Dynamically inject a new mock issue when a new model is synchronized
    // to show interactive reactivity
    const newAutoIssue: SiteIssue = {
      id: `issue-auto-${Date.now()}`,
      title: `Contrôle initial - ${model.name.split('.')[0]}`,
      system: model.systemCounts.HVAC > 0 ? 'HVAC' : 'Electrical',
      priority: 'Moyenne',
      status: 'Nouveau',
      elementName: 'Fichier IFC Frais',
      location: 'Totalité du projet',
      reportedBy: 'BIMTER Parser Automatique',
      date: new Date().toLocaleDateString('fr-FR'),
      description: `La synchronisation du fichier ${model.name} a relevé ${model.clashCount} points d'attention (clashes ou anomalies de géométrie) pré-existants. Veuillez lancer la RA sur site pour vérification.`,
    };
    setIssues((prev) => [newAutoIssue, ...prev]);
  };

  const scrollToSection = (id: string) => {
    const el = document.getElementById(id);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
    setMobileMenuOpen(false);
  };

  const handleContactSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setContactFormSubmitted(true);
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans">
      {/* 1. Header (Navbar) */}
      <header className="sticky top-0 z-50 bg-slate-950/80 backdrop-blur-md border-b border-slate-900/60 transition-all duration-300">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between">
          {/* Logo & Slogan Column */}
          <div className="flex flex-col">
            <div className="flex items-center gap-2">
              {/* Custom High Fidelity SVG Hexagon Logo */}
              <div className="relative w-8 h-8 flex items-center justify-center">
                <svg viewBox="0 0 100 100" className="w-full h-full fill-blue-600 animate-pulse">
                  <polygon points="50,1 95,25 95,75 50,99 5,75 5,25" />
                </svg>
                <div className="absolute inset-0 flex items-center justify-center font-display font-black text-white text-base">
                  B
                </div>
              </div>
              <span className="font-display font-extrabold text-2xl tracking-tight text-white">
                BIMTER
              </span>
            </div>
            <span className="text-[9px] text-slate-400 font-medium tracking-wide mt-0.5 hidden sm:inline">
              Building Intelligence Through Engineering & Reality
            </span>
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center gap-8">
            <button
              onClick={() => scrollToSection('home')}
              className="text-xs font-semibold text-slate-300 hover:text-white transition-colors uppercase tracking-wider"
            >
              Accueil
            </button>
            <button
              onClick={() => scrollToSection('avantages')}
              className="text-xs font-semibold text-slate-300 hover:text-white transition-colors uppercase tracking-wider"
            >
              Avantages
            </button>
            <button
              onClick={() => scrollToSection('fonctionnement')}
              className="text-xs font-semibold text-slate-300 hover:text-white transition-colors uppercase tracking-wider"
            >
              Fonctionnement
            </button>
            <button
              onClick={() => scrollToSection('interactive-demo')}
              className="text-xs font-semibold text-blue-400 hover:text-blue-300 transition-colors uppercase tracking-wider flex items-center gap-1"
            >
              <Sparkles className="w-3 h-3 text-blue-400" />
              Espace Interactif
            </button>
            <button
              onClick={() => scrollToSection('contact')}
              className="py-2.5 px-4 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold transition-all shadow-md shadow-blue-500/10"
            >
              Contacter un expert
            </button>
          </nav>

          {/* Mobile hamburger button */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="md:hidden p-2 text-slate-400 hover:text-white"
          >
            {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>

        {/* Mobile Navigation Dropdown */}
        {mobileMenuOpen && (
          <div className="md:hidden bg-slate-950 border-b border-slate-900 p-5 space-y-4">
            <button
              onClick={() => scrollToSection('home')}
              className="block w-full text-left text-sm font-semibold text-slate-300 hover:text-white py-1"
            >
              Accueil
            </button>
            <button
              onClick={() => scrollToSection('avantages')}
              className="block w-full text-left text-sm font-semibold text-slate-300 hover:text-white py-1"
            >
              Avantages
            </button>
            <button
              onClick={() => scrollToSection('fonctionnement')}
              className="block w-full text-left text-sm font-semibold text-slate-300 hover:text-white py-1"
            >
              Fonctionnement
            </button>
            <button
              onClick={() => scrollToSection('interactive-demo')}
              className="block w-full text-left text-sm font-semibold text-blue-400 hover:text-blue-300 py-1"
            >
              Espace Interactif (Démo)
            </button>
            <button
              onClick={() => scrollToSection('contact')}
              className="w-full text-center py-2.5 px-4 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold block"
            >
              Contacter un expert
            </button>
          </div>
        )}
      </header>

      {/* 2. Hero Section */}
      <section id="home" className="relative py-12 md:py-20 lg:py-24 overflow-hidden border-b border-slate-900/60">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-blue-900/15 via-slate-950 to-slate-950"></div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
            
            {/* Left Content Column */}
            <div className="lg:col-span-6 space-y-6">
              {/* Blue Badge */}
              <div className="inline-flex items-center gap-2 px-3 py-1 bg-blue-500/10 border border-blue-500/20 text-blue-400 text-xs font-bold uppercase rounded-full">
                <span className="w-1.5 h-1.5 rounded-full bg-blue-400 animate-ping"></span>
                BIM + Réalité Augmentée
              </div>

              {/* Main Title */}
              <h1 className="font-display font-extrabold text-3xl sm:text-4xl lg:text-5xl leading-[1.1] tracking-tight text-white">
                Du modèle <span className="text-blue-500">BIM</span> au chantier, <br />
                en <span className="bg-gradient-to-r from-blue-400 to-cyan-400 bg-clip-text text-transparent">réalité augmentée</span>.
              </h1>

              {/* Descriptions matching the physical French image */}
              <p className="text-sm sm:text-base text-slate-300 leading-relaxed font-semibold">
                Visualisez votre maquette BIM directement sur le chantier grâce à la réalité augmentée.
              </p>

              <div className="text-xs sm:text-sm text-slate-400 leading-relaxed space-y-4">
                <p>
                  Connectez votre modèle BIM à <strong className="text-white">GAMMA AR</strong> pour superposer les réseaux MEP (Mécanique, Électricité, Plomberie) directement dans l'environnement réel.
                </p>
                <p>
                  Les équipes de chantier peuvent comparer la maquette numérique avec l'exécution physique en temps réel, détecter instantanément les écarts et résoudre les problèmes techniques complexes avant qu'ils ne génèrent des surcoûts d'installation majeurs.
                </p>
              </div>

              {/* Call to Action Button */}
              <div className="pt-4 flex flex-col sm:flex-row gap-4">
                <button
                  onClick={() => scrollToSection('interactive-demo')}
                  className="py-3.5 px-6 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold tracking-wider uppercase transition-all shadow-lg shadow-blue-500/20 flex items-center justify-center gap-2 group"
                >
                  <Eye className="w-4.5 h-4.5 group-hover:scale-110 transition-transform" />
                  Découvrir notre solution AR
                </button>
                <button
                  onClick={() => scrollToSection('fonctionnement')}
                  className="py-3.5 px-6 rounded-xl bg-slate-900 hover:bg-slate-850 text-slate-300 border border-slate-800 text-xs font-bold tracking-wider uppercase transition-all flex items-center justify-center gap-1"
                >
                  Comment ça fonctionne ?
                  <ChevronRight className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Right Generated Image Column */}
            <div className="lg:col-span-6 relative">
              <div className="relative rounded-2xl overflow-hidden border border-slate-800 shadow-2xl bg-slate-900 group">
                {/* Generated image representing worker looking at BIM pipes overlay */}
                <img
                  src="/src/assets/images/bimter_hero_ar_construction_1784123387908.jpg"
                  alt="BIMTER Réalité Augmentée sur Chantier"
                  referrerPolicy="no-referrer"
                  className="w-full h-auto object-cover opacity-95 group-hover:scale-102 transition-transform duration-700"
                />
                
                {/* Soft scanline overlay to simulate HUD camera */}
                <div className="absolute inset-0 bg-gradient-to-t from-slate-950/60 via-transparent to-transparent pointer-events-none"></div>
                <div className="absolute bottom-4 right-4 flex items-center gap-2 bg-slate-950/80 backdrop-blur border border-slate-800 rounded-lg px-3 py-1.5 text-[10px] font-mono text-slate-300 shadow-lg">
                  <Smartphone className="w-3.5 h-3.5 text-blue-400" />
                  <span>SIMULATION ACTIVE</span>
                </div>
              </div>

              {/* Floating micro stats element */}
              <div className="absolute -bottom-6 -left-6 bg-slate-900 border border-slate-800 rounded-xl p-4 shadow-xl hidden md:flex items-center gap-3 max-w-xs">
                <div className="w-10 h-10 rounded-lg bg-blue-500/10 flex items-center justify-center text-blue-400 shrink-0">
                  <CheckCircle className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="text-xs font-bold text-white">Précision Millimétrique</h4>
                  <p className="text-[10px] text-slate-400">Alignement de la maquette de l'ordre de &lt; 5mm sur site.</p>
                </div>
              </div>
            </div>

          </div>
        </div>
      </section>

      {/* 3. Horizontal Benefits/Features Row (6 boxes matched with physical image) */}
      <section id="avantages" className="py-12 bg-slate-950 border-b border-slate-900/60">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-3xl mx-auto mb-10">
            <span className="text-[10px] uppercase font-bold tracking-widest text-blue-400">Atouts Clés</span>
            <h2 className="font-display font-bold text-2xl text-white mt-1">Efficacité et Conformité d'Installation</h2>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
            
            {/* Benefit 1 */}
            <div className="bg-slate-900/40 border border-slate-850 p-4.5 rounded-xl flex flex-col items-center text-center hover:border-slate-800 transition-all">
              <div className="w-9 h-9 rounded-lg bg-blue-500/10 flex items-center justify-center text-blue-400 mb-3.5">
                <Compass className="w-5 h-5" />
              </div>
              <h4 className="font-semibold text-xs text-slate-200 leading-snug">
                Visualisation BIM en réalité augmentée sur site
              </h4>
            </div>

            {/* Benefit 2 */}
            <div className="bg-slate-900/40 border border-slate-850 p-4.5 rounded-xl flex flex-col items-center text-center hover:border-slate-800 transition-all">
              <div className="w-9 h-9 rounded-lg bg-cyan-500/10 flex items-center justify-center text-cyan-400 mb-3.5">
                <FileCheck className="w-5 h-5" />
              </div>
              <h4 className="font-semibold text-xs text-slate-200 leading-snug">
                Vérification de la conformité des installations
              </h4>
            </div>

            {/* Benefit 3 */}
            <div className="bg-slate-900/40 border border-slate-850 p-4.5 rounded-xl flex flex-col items-center text-center hover:border-slate-800 transition-all">
              <div className="w-9 h-9 rounded-lg bg-amber-500/10 flex items-center justify-center text-amber-400 mb-3.5">
                <AlertTriangle className="w-5 h-5" />
              </div>
              <h4 className="font-semibold text-xs text-slate-200 leading-snug">
                Détection des écarts entre maquette et exécution
              </h4>
            </div>

            {/* Benefit 4 */}
            <div className="bg-slate-900/40 border border-slate-850 p-4.5 rounded-xl flex flex-col items-center text-center hover:border-slate-800 transition-all">
              <div className="w-9 h-9 rounded-lg bg-purple-500/10 flex items-center justify-center text-purple-400 mb-3.5">
                <Layers className="w-5 h-5" />
              </div>
              <h4 className="font-semibold text-xs text-slate-200 leading-snug">
                Suivi des réservations et des réseaux MEP
              </h4>
            </div>

            {/* Benefit 5 */}
            <div className="bg-slate-900/40 border border-slate-850 p-4.5 rounded-xl flex flex-col items-center text-center hover:border-slate-800 transition-all">
              <div className="w-9 h-9 rounded-lg bg-green-500/10 flex items-center justify-center text-green-400 mb-3.5">
                <Users className="w-5 h-5" />
              </div>
              <h4 className="font-semibold text-xs text-slate-200 leading-snug">
                Collaboration en temps réel Bureau ↔ Chantier
              </h4>
            </div>

            {/* Benefit 6 */}
            <div className="bg-slate-900/40 border border-slate-850 p-4.5 rounded-xl flex flex-col items-center text-center hover:border-slate-800 transition-all">
              <div className="w-9 h-9 rounded-lg bg-red-500/10 flex items-center justify-center text-red-400 mb-3.5">
                <TrendingDown className="w-5 h-5" />
              </div>
              <h4 className="font-semibold text-xs text-slate-200 leading-snug">
                Réduction des reprises et erreurs d'installation
              </h4>
            </div>

          </div>
        </div>
      </section>

      {/* 4. "Comment ça fonctionne ?" Sequential Steps Section */}
      <section id="fonctionnement" className="py-16 md:py-20 bg-slate-950/40 border-b border-slate-900/60">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-2xl mx-auto mb-12">
            <span className="text-[10px] uppercase font-bold tracking-widest text-blue-400 font-mono">Processus simple</span>
            <h2 className="font-display font-extrabold text-2xl sm:text-3xl text-white mt-1 uppercase tracking-wide">
              Comment ça fonctionne ?
            </h2>
            <div className="w-12 h-1 bg-blue-600 mx-auto mt-3 rounded-full"></div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-4 gap-6 relative">
            
            {/* Step 1 */}
            <div className="bg-slate-900/50 border border-slate-850 rounded-xl p-5 relative overflow-hidden flex flex-col justify-between min-h-[190px] hover:border-blue-500/30 transition-all">
              <div>
                <span className="font-mono text-3xl font-extrabold text-blue-500/20 block">01</span>
                <div className="w-8 h-8 rounded-lg bg-blue-500/10 flex items-center justify-center text-blue-400 mb-3">
                  <Monitor className="w-4.5 h-4.5" />
                </div>
                <h4 className="font-bold text-xs text-white mb-1.5 uppercase tracking-wide">
                  Import Maquette
                </h4>
                <p className="text-[11px] text-slate-400 leading-relaxed">
                  Importez votre maquette BIM (formats standardisés Revit ou IFC).
                </p>
              </div>
              <div className="text-[10px] text-slate-500 font-semibold flex items-center gap-1.5 pt-4">
                <span>Phase CAO/BIM</span>
                <ArrowRight className="w-3 h-3 text-slate-600 hidden md:inline" />
              </div>
            </div>

            {/* Step 2 */}
            <div className="bg-slate-900/50 border border-slate-850 rounded-xl p-5 relative overflow-hidden flex flex-col justify-between min-h-[190px] hover:border-blue-500/30 transition-all">
              <div>
                <span className="font-mono text-3xl font-extrabold text-blue-500/20 block">02</span>
                <div className="w-8 h-8 rounded-lg bg-blue-500/10 flex items-center justify-center text-blue-400 mb-3">
                  <CloudLightning className="w-4.5 h-4.5" />
                </div>
                <h4 className="font-bold text-xs text-white mb-1.5 uppercase tracking-wide">
                  Synchronisation
                </h4>
                <p className="text-[11px] text-slate-400 leading-relaxed">
                  Synchronisez le modèle 3D instantanément avec la plateforme GAMMA AR.
                </p>
              </div>
              <div className="text-[10px] text-slate-500 font-semibold flex items-center gap-1.5 pt-4">
                <span>Cloud BIMTER</span>
                <ArrowRight className="w-3 h-3 text-slate-600 hidden md:inline" />
              </div>
            </div>

            {/* Step 3 */}
            <div className="bg-slate-900/50 border border-slate-850 rounded-xl p-5 relative overflow-hidden flex flex-col justify-between min-h-[190px] hover:border-blue-500/30 transition-all">
              <div>
                <span className="font-mono text-3xl font-extrabold text-blue-500/20 block">03</span>
                <div className="w-8 h-8 rounded-lg bg-blue-500/10 flex items-center justify-center text-blue-400 mb-3">
                  <Smartphone className="w-4.5 h-4.5" />
                </div>
                <h4 className="font-bold text-xs text-white mb-1.5 uppercase tracking-wide">
                  Visualisation RA
                </h4>
                <p className="text-[11px] text-slate-400 leading-relaxed">
                  Visualisez les réseaux BIM directement sur le chantier en Réalité Augmentée.
                </p>
              </div>
              <div className="text-[10px] text-slate-500 font-semibold flex items-center gap-1.5 pt-4">
                <span>Casque ou Tablette</span>
                <ArrowRight className="w-3 h-3 text-slate-600 hidden md:inline" />
              </div>
            </div>

            {/* Step 4 */}
            <div className="bg-slate-900/50 border border-slate-850 rounded-xl p-5 relative overflow-hidden flex flex-col justify-between min-h-[190px] hover:border-blue-500/30 transition-all">
              <div>
                <span className="font-mono text-3xl font-extrabold text-blue-500/20 block">04</span>
                <div className="w-8 h-8 rounded-lg bg-blue-500/10 flex items-center justify-center text-blue-400 mb-3">
                  <AlertTriangle className="w-4.5 h-4.5" />
                </div>
                <h4 className="font-bold text-xs text-white mb-1.5 uppercase tracking-wide">
                  Contrôle & Écarts
                </h4>
                <p className="text-[11px] text-slate-400 leading-relaxed">
                  Comparez le modèle théorique à l'exécution réelle et documentez les écarts.
                </p>
              </div>
              <div className="text-[10px] text-slate-500 font-semibold flex items-center gap-1.5 pt-4">
                <span>Rapports chantiers</span>
              </div>
            </div>

          </div>
        </div>
      </section>

      {/* 5. INTERACTIVE WORKSPACE DEMO SECTION (High craft playground) */}
      <section id="interactive-demo" className="py-16 md:py-20 bg-slate-950 border-b border-slate-900/60 relative">
        <div className="absolute inset-0 bg-gradient-to-b from-slate-950 via-blue-950/5 to-slate-950"></div>
        
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
          
          {/* Section Header */}
          <div className="flex flex-col md:flex-row justify-between items-start md:items-end mb-8 gap-4">
            <div>
              <div className="flex items-center gap-1.5 text-blue-400">
                <Sparkles className="w-4 h-4 text-blue-400" />
                <span className="text-[10px] uppercase font-bold tracking-widest font-mono">Espace de Démonstration</span>
              </div>
              <h2 className="font-display font-extrabold text-2xl sm:text-3xl text-white mt-1">
                Espace Applicatif Interactif
              </h2>
              <p className="text-xs text-slate-400 mt-1 max-w-xl">
                Testez en direct les fonctionnalités clés de BIMTER. Utilisez les contrôles ci-dessous pour changer de module.
              </p>
            </div>

            {/* Tab Swapping Controls */}
            <div className="flex p-1 bg-slate-900 border border-slate-800 rounded-xl shrink-0 self-stretch md:self-auto overflow-x-auto">
              <button
                onClick={() => setActiveTab('ar')}
                className={`flex-1 md:flex-none py-2 px-4 rounded-lg text-xs font-semibold transition-all whitespace-nowrap ${
                  activeTab === 'ar'
                    ? 'bg-blue-600 text-white shadow-md'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                1. Simulateur RA
              </button>
              <button
                onClick={() => setActiveTab('sync')}
                className={`flex-1 md:flex-none py-2 px-4 rounded-lg text-xs font-semibold transition-all whitespace-nowrap ${
                  activeTab === 'sync'
                    ? 'bg-blue-600 text-white shadow-md'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                2. Sync Cloud Revit/IFC
              </button>
              <button
                onClick={() => setActiveTab('log')}
                className={`flex-1 md:flex-none py-2 px-4 rounded-lg text-xs font-semibold transition-all whitespace-nowrap ${
                  activeTab === 'log'
                    ? 'bg-blue-600 text-white shadow-md'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                3. Registre des Écarts ({issues.length})
              </button>
            </div>
          </div>

          {/* Active Workspace Container */}
          <div className="bg-slate-900/25 border border-slate-850 rounded-3xl p-6 md:p-8 shadow-2xl">
            {activeTab === 'ar' && (
              <ARSimulator
                issues={issues}
                onAddIssue={handleAddIssue}
                selectedIssueId={selectedIssueId}
                onSelectIssue={setSelectedIssueId}
              />
            )}

            {activeTab === 'sync' && (
              <IFCSync
                onModelLoaded={(model) => {
                  handleModelLoaded(model);
                  setActiveTab('ar'); // Auto navigate to viewer to preview it
                }}
              />
            )}

            {activeTab === 'log' && (
              <IssuesLog
                issues={issues}
                selectedIssueId={selectedIssueId}
                onSelectIssue={setSelectedIssueId}
                onResolveIssue={handleResolveIssue}
                onDeleteIssue={handleDeleteIssue}
              />
            )}
          </div>

        </div>
      </section>

      {/* 6. Lead Generation Form / Contact Expert */}
      <section id="contact" className="py-16 md:py-20 bg-slate-950/40 relative">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 relative">
          
          <div className="bg-gradient-to-r from-blue-950/50 to-slate-900/80 border border-slate-800 rounded-3xl p-8 shadow-2xl relative overflow-hidden">
            <div className="absolute top-0 right-0 transform translate-x-1/3 -translate-y-1/3 w-96 h-96 bg-blue-500/10 rounded-full blur-3xl pointer-events-none"></div>

            <div className="text-center max-w-xl mx-auto mb-8">
              <div className="inline-flex p-3 bg-blue-500/10 rounded-2xl text-blue-400 mb-3 border border-blue-500/20">
                <PhoneCall className="w-6 h-6" />
              </div>
              <h3 className="font-display font-extrabold text-2xl text-white">
                Prêt à intégrer la Réalité Augmentée ?
              </h3>
              <p className="text-xs text-slate-400 mt-1.5">
                Demandez une consultation gratuite avec nos ingénieurs BIM et planifiez un essai de casque RA sur votre chantier.
              </p>
            </div>

            {contactFormSubmitted ? (
              <div className="bg-emerald-500/10 border border-emerald-500/30 rounded-2xl p-6 text-center text-emerald-400 max-w-md mx-auto">
                <CheckCircle className="w-12 h-12 mx-auto mb-3 text-emerald-400" />
                <h4 className="font-display font-bold text-sm uppercase tracking-wide">
                  Demande envoyée !
                </h4>
                <p className="text-xs text-slate-300 mt-1.5 leading-relaxed">
                  Merci pour votre intérêt. Un ingénieur technique BIMTER vous recontactera sous 24h ouvrées pour préparer le matériel de test.
                </p>
                <button
                  onClick={() => setContactFormSubmitted(false)}
                  className="mt-4 text-xs font-semibold underline text-emerald-400 hover:text-emerald-300"
                >
                  Envoyer une autre demande
                </button>
              </div>
            ) : (
              <form onSubmit={handleContactSubmit} className="grid grid-cols-1 md:grid-cols-2 gap-4 max-w-2xl mx-auto">
                <div>
                  <label className="block text-[10px] uppercase font-bold text-slate-400 mb-1">
                    Nom & Prénom *
                  </label>
                  <input
                    type="text"
                    required
                    value={clientName}
                    onChange={(e) => setClientName(e.target.value)}
                    placeholder="ex: Jean Dupont"
                    className="w-full text-xs bg-slate-950 border border-slate-800 rounded-lg px-3 py-2.5 text-white focus:outline-none focus:border-blue-500"
                  />
                </div>

                <div>
                  <label className="block text-[10px] uppercase font-bold text-slate-400 mb-1">
                    Adresse Email professionnelle *
                  </label>
                  <input
                    type="email"
                    required
                    value={clientEmail}
                    onChange={(e) => setClientEmail(e.target.value)}
                    placeholder="ex: j.dupont@construction-corp.com"
                    className="w-full text-xs bg-slate-950 border border-slate-800 rounded-lg px-3 py-2.5 text-white focus:outline-none focus:border-blue-500"
                  />
                </div>

                <div>
                  <label className="block text-[10px] uppercase font-bold text-slate-400 mb-1">
                    Numéro de Téléphone *
                  </label>
                  <input
                    type="tel"
                    required
                    value={clientPhone}
                    onChange={(e) => setClientPhone(e.target.value)}
                    placeholder="ex: +33 6 12 34 56 78"
                    className="w-full text-xs bg-slate-950 border border-slate-800 rounded-lg px-3 py-2.5 text-white focus:outline-none focus:border-blue-500"
                  />
                </div>

                <div>
                  <label className="block text-[10px] uppercase font-bold text-slate-400 mb-1">
                    Secteur / Type de Projet Principal
                  </label>
                  <select
                    value={clientProject}
                    onChange={(e) => setClientProject(e.target.value)}
                    className="w-full text-xs bg-slate-950 border border-slate-800 rounded-lg px-3 py-2.5 text-white focus:outline-none focus:border-blue-500"
                  >
                    <option value="Hospitalier">Hospitalier & Médical</option>
                    <option value="Tertiaire">Tertiaire & Bureaux complexes</option>
                    <option value="Residentiel">Résidentiel collectif</option>
                    <option value="Industriel">Centres de données & Usines</option>
                  </select>
                </div>

                <div className="md:col-span-2 mt-4">
                  <button
                    type="submit"
                    className="w-full py-3 px-6 bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs uppercase tracking-wider rounded-xl transition-all shadow-lg shadow-blue-500/20 flex items-center justify-center gap-2"
                  >
                    <Send className="w-4.5 h-4.5" />
                    Valider ma demande d'essai gratuit
                  </button>
                  <span className="block text-[10px] text-slate-500 text-center mt-2.5">
                    * En soumettant ce formulaire, vous acceptez d'être recontacté pour l'évaluation technique de votre chantier.
                  </span>
                </div>
              </form>
            )}

          </div>
        </div>
      </section>

      {/* 7. Footer Stats Banner (Dark blue band at bottom) */}
      <footer className="bg-blue-750 text-white border-t border-blue-900 mt-auto">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 text-center">
            
            {/* Stat item 1 */}
            <div className="space-y-1">
              <div className="text-sm font-bold text-white flex items-center justify-center gap-1.5">
                <span className="w-1.5 h-1.5 rounded-full bg-cyan-400"></span>
                100 % COMPATIBLE
              </div>
              <p className="text-[11px] text-blue-100 font-medium">Revit & IFC</p>
            </div>

            {/* Stat item 2 */}
            <div className="space-y-1 border-l border-blue-800/60">
              <div className="text-sm font-bold text-white flex items-center justify-center gap-1.5">
                <span className="w-1.5 h-1.5 rounded-full bg-cyan-400"></span>
                DÉTECTION DES ÉCARTS
              </div>
              <p className="text-[11px] text-blue-100 font-medium">Avant installation physique</p>
            </div>

            {/* Stat item 3 */}
            <div className="space-y-1 border-l border-blue-800/60">
              <div className="text-sm font-bold text-white flex items-center justify-center gap-1.5">
                <span className="w-1.5 h-1.5 rounded-full bg-cyan-400"></span>
                DOCUMENTATION
              </div>
              <p className="text-[11px] text-blue-100 font-medium">Instantanée sur site</p>
            </div>

            {/* Stat item 4 */}
            <div className="space-y-1 border-l border-blue-800/60">
              <div className="text-sm font-bold text-white flex items-center justify-center gap-1.5">
                <span className="w-1.5 h-1.5 rounded-full bg-cyan-400"></span>
                COLLABORATION
              </div>
              <p className="text-[11px] text-blue-100 font-medium">Bureau ↔ Chantier fluide</p>
            </div>

          </div>

          {/* Subfooter bottom copyright */}
          <div className="border-t border-blue-800/40 mt-8 pt-6 flex flex-col sm:flex-row justify-between items-center text-[10px] text-blue-200 gap-4">
            <div className="flex items-center gap-2">
              <span className="font-extrabold">BIMTER</span>
              <span>© {new Date().getFullYear()} - Plateforme de Réalité Augmentée Professionnelle.</span>
            </div>
            <div className="flex gap-4">
              <span>Conditions Générales</span>
              <span>Politique de Confidentialité</span>
              <span>Propulsé par GAMMA AR</span>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
