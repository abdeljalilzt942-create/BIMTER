export type SystemType = 'HVAC' | 'Plumbing' | 'Electrical' | 'Structural' | 'FireProtection';

export interface BIMElement {
  id: string;
  name: string;
  system: SystemType;
  diameter?: string;
  flowRate?: string;
  voltage?: string;
  material: string;
  elevation: string;
  status: 'Conforme' | 'Écart Détecté';
  coordinates: { x: number; y: number }; // Percentage coordinate for the hotspot
}

export interface SiteIssue {
  id: string;
  title: string;
  system: SystemType;
  priority: 'Haute' | 'Moyenne' | 'Basse';
  status: 'Nouveau' | 'En cours' | 'Résolu';
  elementName: string;
  location: string;
  reportedBy: string;
  date: string;
  description: string;
  coordinateX?: number; // Optional position in the AR simulator
  coordinateY?: number;
}

export interface MockModel {
  id: string;
  name: string;
  fileSize: string;
  fileType: 'IFC' | 'RVT';
  version: string;
  elementCount: number;
  systemCounts: Record<SystemType, number>;
  clashCount: number;
}
