import React, { useState, useRef } from 'react';
import { Eye, EyeOff, Layers, Info, AlertTriangle, Plus, CheckCircle, Smartphone, Sliders } from 'lucide-react';
import { BIMElement, SiteIssue, SystemType } from '../types';
import { motion, AnimatePresence } from 'motion/react';

interface ARSimulatorProps {
  issues: SiteIssue[];
  onAddIssue: (issue: SiteIssue) => void;
  selectedIssueId: string | null;
  onSelectIssue: (id: string | null) => void;
}

const PRESET_ELEMENTS: BIMElement[] = [
  {
    id: 'elem-1',
    name: 'Gaine de Ventilation Primaire (HVAC-SUP-04)',
    system: 'HVAC',
    diameter: '500mm x 400mm',
    flowRate: '1500 m³/h',
    material: 'Acier Galvanisé avec Isolation Thermique',
    elevation: '+3.15 m sous dalle',
    status: 'Conforme',
    coordinates: { x: 35, y: 28 },
  },
  {
    id: 'elem-2',
    name: 'Collecteur Eau Froide Générale (PL-EF-012)',
    system: 'Plumbing',
    diameter: 'Ø 80mm',
    material: 'Cuivre soudé haute pression',
    elevation: '+2.85 m',
    status: 'Écart Détecté',
    coordinates: { x: 65, y: 48 },
  },
  {
    id: 'elem-3',
    name: 'Chemin de Câble Force & Énergie (ELE-CF-02)',
    system: 'Electrical',
    voltage: '400V / 50Hz',
    material: 'Dalle d\'aluminium perforée',
    elevation: '+3.45 m',
    status: 'Conforme',
    coordinates: { x: 78, y: 18 },
  },
  {
    id: 'elem-4',
    name: 'Antenne de Sprinkler Automatique (INC-SP-09)',
    system: 'FireProtection',
    diameter: 'Ø 40mm',
    material: 'Acier noir fileté',
    elevation: '+3.55 m',
    status: 'Conforme',
    coordinates: { x: 22, y: 15 },
  },
];

export default function ARSimulator({
  issues,
  onAddIssue,
  selectedIssueId,
  onSelectIssue,
}: ARSimulatorProps) {
  const [arOpacity, setArOpacity] = useState<number>(85);
  const [selectedSystems, setSelectedSystems] = useState<Record<SystemType, boolean>>({
    HVAC: true,
    Plumbing: true,
    Electrical: true,
    Structural: true,
    FireProtection: true,
  });

  const [inspectingElement, setInspectingElement] = useState<BIMElement | null>(null);
  const [isAddingIssueMode, setIsAddingIssueMode] = useState<boolean>(false);
  const [clickCoordinates, setClickCoordinates] = useState<{ x: number; y: number } | null>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  // Form states for creating a custom discrepancy
  const [newIssueTitle, setNewIssueTitle] = useState('');
  const [newIssueDesc, setNewIssueDesc] = useState('');
  const [newIssueSystem, setNewIssueSystem] = useState<SystemType>('HVAC');
  const [newIssuePriority, setNewIssuePriority] = useState<'Haute' | 'Moyenne' | 'Basse'>('Moyenne');

  const toggleSystem = (system: SystemType) => {
    setSelectedSystems((prev) => ({ ...prev, [system]: !prev[system] }));
  };

  const handleCanvasClick = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!isAddingIssueMode || !containerRef.current) return;

    const rect = containerRef.current.getBoundingClientRect();
    const x = Math.round(((e.clientX - rect.left) / rect.width) * 100);
    const y = Math.round(((e.clientY - rect.top) / rect.height) * 100);

    setClickCoordinates({ x, y });
  };

  const handleCreateIssueSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!clickCoordinates || !newIssueTitle.trim()) return;

    const newIssue: SiteIssue = {
      id: `issue-custom-${Date.now()}`,
      title: newIssueTitle,
      system: newIssueSystem,
      priority: newIssuePriority,
      status: 'Nouveau',
      elementName: `Élément personnalisé au point (${clickCoordinates.x}%, ${clickCoordinates.y}%)`,
      location: 'Niveau 2 - Zone Centrale (Chantier)',
      reportedBy: 'Superviseur de Chantier (Vous)',
      date: new Date().toLocaleDateString('fr-FR'),
      description: newIssueDesc || 'Aucune description fournie.',
      coordinateX: clickCoordinates.x,
      coordinateY: clickCoordinates.y,
    };

    onAddIssue(newIssue);
    setIsAddingIssueMode(false);
    setClickCoordinates(null);
    setNewIssueTitle('');
    setNewIssueDesc('');
    onSelectIssue(newIssue.id);
  };

  const cancelAddingIssue = () => {
    setIsAddingIssueMode(false);
    setClickCoordinates(null);
    setNewIssueTitle('');
    setNewIssueDesc('');
  };

  const getSystemColor = (system: SystemType) => {
    switch (system) {
      case 'HVAC':
        return 'stroke-green-400 fill-green-400 text-green-400';
      case 'Plumbing':
        return 'stroke-blue-400 fill-blue-400 text-blue-400';
      case 'Electrical':
        return 'stroke-yellow-400 fill-yellow-400 text-yellow-400';
      case 'FireProtection':
        return 'stroke-red-500 fill-red-500 text-red-500';
      case 'Structural':
        return 'stroke-slate-300 fill-slate-300 text-slate-300';
    }
  };

  const getSystemBg = (system: SystemType) => {
    switch (system) {
      case 'HVAC':
        return 'bg-green-500/15 border-green-500 text-green-400';
      case 'Plumbing':
        return 'bg-blue-500/15 border-blue-500 text-blue-400';
      case 'Electrical':
        return 'bg-yellow-500/15 border-yellow-500 text-yellow-400';
      case 'FireProtection':
        return 'bg-red-500/15 border-red-500 text-red-400';
      case 'Structural':
        return 'bg-slate-500/15 border-slate-500 text-slate-300';
    }
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
      {/* Sidebar Control Panel */}
      <div className="lg:col-span-1 bg-slate-900/60 backdrop-blur-md p-5 rounded-2xl border border-slate-800 flex flex-col justify-between">
        <div>
          <div className="flex items-center gap-2 mb-4">
            <Layers className="w-5 h-5 text-blue-400" />
            <h3 className="font-display font-semibold text-lg text-white">Contrôle AR</h3>
          </div>

          <p className="text-xs text-slate-400 mb-6">
            Contrôlez l'affichage de la maquette BIM et simulez la caméra de réalité augmentée.
          </p>

          {/* Opacity Slider */}
          <div className="mb-6">
            <div className="flex justify-between items-center mb-2">
              <span className="text-xs font-medium text-slate-300 flex items-center gap-1.5">
                <Sliders className="w-3.5 h-3.5 text-blue-400" />
                Opacité de la maquette
              </span>
              <span className="text-xs font-mono font-bold text-blue-400">{arOpacity}%</span>
            </div>
            <input
              type="range"
              min="0"
              max="100"
              value={arOpacity}
              onChange={(e) => setArOpacity(parseInt(e.target.value))}
              className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-blue-500"
            />
            <div className="flex justify-between text-[10px] text-slate-500 mt-1">
              <span>Chantier réel</span>
              <span>Mixte (RA)</span>
              <span>BIM Pur</span>
            </div>
          </div>

          {/* MEP Filters */}
          <div className="mb-6">
            <span className="text-xs font-medium text-slate-300 block mb-3">Réseaux Techniques</span>
            <div className="space-y-2">
              {(['HVAC', 'Plumbing', 'Electrical', 'FireProtection'] as SystemType[]).map((sys) => {
                const isSelected = selectedSystems[sys];
                const sysLabels: Record<SystemType, string> = {
                  HVAC: 'Gaines Ventilation (HVAC)',
                  Plumbing: 'Plomberie & Fluides',
                  Electrical: 'Électricité & Câblages',
                  FireProtection: 'Sécurité Incendie',
                  Structural: 'Structure Béton/Métal',
                };
                const colorMap: Record<SystemType, string> = {
                  HVAC: 'border-green-500 text-green-400 bg-green-500/10',
                  Plumbing: 'border-blue-500 text-blue-400 bg-blue-500/10',
                  Electrical: 'border-yellow-500 text-yellow-400 bg-yellow-500/10',
                  FireProtection: 'border-red-500 text-red-400 bg-red-500/10',
                  Structural: 'border-slate-500 text-slate-400 bg-slate-500/10',
                };

                return (
                  <button
                    key={sys}
                    onClick={() => toggleSystem(sys)}
                    className={`w-full text-left p-2.5 rounded-xl text-xs font-medium border transition-all flex items-center justify-between ${
                      isSelected
                        ? `${colorMap[sys]} shadow-[0_0_12px_rgba(0,0,0,0.3)]`
                        : 'border-slate-800 text-slate-500 bg-slate-950/40 hover:border-slate-700'
                    }`}
                  >
                    <span>{sysLabels[sys]}</span>
                    {isSelected ? (
                      <Eye className="w-3.5 h-3.5" />
                    ) : (
                      <EyeOff className="w-3.5 h-3.5 text-slate-600" />
                    )}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Action Button: Discrepancy mode */}
          <button
            onClick={() => {
              setIsAddingIssueMode(!isAddingIssueMode);
              setClickCoordinates(null);
            }}
            className={`w-full py-3 px-4 rounded-xl text-xs font-semibold flex items-center justify-center gap-2 transition-all ${
              isAddingIssueMode
                ? 'bg-red-500 hover:bg-red-600 text-white shadow-lg shadow-red-500/20'
                : 'bg-blue-600 hover:bg-blue-700 text-white shadow-lg shadow-blue-500/20'
            }`}
          >
            {isAddingIssueMode ? (
              <>
                <Eye className="w-4 h-4" />
                Quitter le mode d'édition
              </>
            ) : (
              <>
                <Plus className="w-4 h-4" />
                Signaler un Écart (RA)
              </>
            )}
          </button>
        </div>

        {/* Tip */}
        <div className="mt-6 p-3 bg-slate-950/60 rounded-xl border border-slate-800/80">
          <div className="flex gap-2 items-start">
            <Smartphone className="w-4 h-4 text-blue-400 shrink-0 mt-0.5" />
            <p className="text-[10px] text-slate-400 leading-relaxed">
              {isAddingIssueMode
                ? "Cliquez directement sur l'image de chantier à droite pour pointer et documenter un écart physique par rapport au plan BIM."
                : 'Survolez ou cliquez sur les points de raccordement fluorescents pour inspecter les métadonnées BIM extraites de la maquette.'}
            </p>
          </div>
        </div>
      </div>

      {/* Main Interactive AR Viewer Canvas */}
      <div className="lg:col-span-3 flex flex-col gap-4">
        <div className="relative overflow-hidden rounded-2xl border border-slate-800 bg-slate-950 h-[480px] select-none shadow-2xl">
          {/* Background: Construction site simulation */}
          {/* We will draw a perspective room using SVG and grids to give a genuine 3D spatial feeling */}
          <div
            id="ar-viewport"
            ref={containerRef}
            onClick={handleCanvasClick}
            className={`absolute inset-0 transition-all duration-300 cursor-crosshair ${
              isAddingIssueMode ? 'cursor-pointer ring-2 ring-red-500' : ''
            }`}
          >
            {/* The 3D MEP Model Backdrop (Reality) */}
            <img
              src="/src/assets/images/mep_ar_model_1784124071490.jpg"
              alt="BIM MEP Model Reality Background"
              referrerPolicy="no-referrer"
              className="absolute inset-0 w-full h-full object-cover opacity-90"
            />

            {/* Subtle ambient gradient overlay for readability and HUD look */}
            <div className="absolute inset-0 bg-gradient-to-t from-slate-950/40 via-transparent to-slate-950/20 pointer-events-none"></div>

            {/* ----------------- BIM MODEL OVERLAY (AR LAYER) ----------------- */}
            <div
              className="absolute inset-0 pointer-events-none transition-opacity duration-200"
              style={{ opacity: arOpacity / 100 }}
            >
              <svg className="w-full h-full" xmlns="http://www.w3.org/2000/svg">
                {/* Simulated AR Glow filter */}
                <defs>
                  <filter id="glow-hvac" x="-20%" y="-20%" width="140%" height="140%">
                    <feGaussianBlur stdDeviation="6" result="blur" />
                    <feComposite in="SourceGraphic" in2="blur" operator="over" />
                  </filter>
                  <filter id="glow-plumb" x="-20%" y="-20%" width="140%" height="140%">
                    <feGaussianBlur stdDeviation="6" result="blur" />
                    <feComposite in="SourceGraphic" in2="blur" operator="over" />
                  </filter>
                  <filter id="glow-ele" x="-20%" y="-20%" width="140%" height="140%">
                    <feGaussianBlur stdDeviation="4" result="blur" />
                    <feComposite in="SourceGraphic" in2="blur" operator="over" />
                  </filter>
                  <filter id="glow-fire" x="-20%" y="-20%" width="140%" height="140%">
                    <feGaussianBlur stdDeviation="5" result="blur" />
                    <feComposite in="SourceGraphic" in2="blur" operator="over" />
                  </filter>
                </defs>

                {/* Grid Overlay to look technical */}
                <g stroke="#ffffff" strokeWidth="0.5" opacity="0.08">
                  <path d="M0,40 H1000 M0,80 H1000 M0,120 H1000 M0,160 H1000 M0,200 H1000 M0,240 H1000 M0,280 H1000 M0,320 H1000 M0,360 H1000 M0,400 H1000" />
                  <path d="M50,0 V480 M100,0 V480 M150,0 V480 M200,0 V480 M250,0 V480 M300,0 V480 M350,0 V480 M400,0 V480 M450,0 V480 M500,0 V480 M550,0 V480 M600,0 V480 M650,0 V480 M700,0 V480 M750,0 V480 M800,0 V480" />
                </g>

                {/* 1. HVAC Systems (Green Ventilation Ducts) */}
                {selectedSystems.HVAC && (
                  <g filter="url(#glow-hvac)">
                    {/* Big primary duct */}
                    <path
                      d="M 0,110 L 400,150 L 520,150 L 1000,200"
                      fill="none"
                      stroke="#22c55e"
                      strokeWidth="32"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      opacity="0.65"
                    />
                    <path
                      d="M 0,110 L 400,150 L 520,150 L 1000,200"
                      fill="none"
                      stroke="#4ade80"
                      strokeWidth="24"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      opacity="0.8"
                    />
                    {/* HVAC Joint contours to look real 3D */}
                    <path d="M 120,113 L 130,131" stroke="#15803d" strokeWidth="2" opacity="0.6" />
                    <path d="M 280,129 L 290,147" stroke="#15803d" strokeWidth="2" opacity="0.6" />
                    {/* Secondary branches */}
                    <path
                      d="M 400,150 L 400,280"
                      fill="none"
                      stroke="#22c55e"
                      strokeWidth="16"
                      strokeLinecap="round"
                      opacity="0.75"
                    />
                    <path
                      d="M 400,280 L 480,310"
                      fill="none"
                      stroke="#22c55e"
                      strokeWidth="12"
                      strokeLinecap="round"
                      opacity="0.75"
                    />
                  </g>
                )}

                {/* 2. Plumbing Fluid Systems (Blue Pipes) */}
                {selectedSystems.Plumbing && (
                  <g filter="url(#glow-plumb)">
                    <path
                      d="M 100,480 L 100,250 L 650,225 L 800,400"
                      fill="none"
                      stroke="#3b82f6"
                      strokeWidth="12"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      opacity="0.7"
                    />
                    {/* Double conduits for Hot/Cold water */}
                    <path
                      d="M 115,480 L 115,262 L 652,237 L 812,408"
                      fill="none"
                      stroke="#60a5fa"
                      strokeWidth="8"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      opacity="0.7"
                    />
                    {/* Slanted actual pipe representing the logged issue location */}
                    {/* (The physical pipe on site was built shifted, causing an issue) */}
                    <line x1="640" y1="225" x2="660" y2="225" stroke="#1d4ed8" strokeWidth="3" />
                  </g>
                )}

                {/* 3. Fire Protection (Red Sprinkler Lines) */}
                {selectedSystems.FireProtection && (
                  <g filter="url(#glow-fire)">
                    <path
                      d="M 0,60 L 1000,90"
                      fill="none"
                      stroke="#ef4444"
                      strokeWidth="8"
                      strokeLinecap="round"
                      opacity="0.8"
                    />
                    {/* Drop sprinkler heads */}
                    <line x1="150" y1="65" x2="150" y2="85" stroke="#b91c1c" strokeWidth="4" />
                    <circle cx="150" cy="85" r="5" fill="#ef4444" />
                    <line x1="350" y1="71" x2="350" y2="91" stroke="#b91c1c" strokeWidth="4" />
                    <circle cx="350" cy="91" r="5" fill="#ef4444" />
                    <line x1="550" y1="77" x2="550" y2="97" stroke="#b91c1c" strokeWidth="4" />
                    <circle cx="550" cy="97" r="5" fill="#ef4444" />
                    <line x1="750" y1="83" x2="750" y2="103" stroke="#b91c1c" strokeWidth="4" />
                    <circle cx="750" cy="103" r="5" fill="#ef4444" />
                  </g>
                )}

                {/* 4. Electrical Conduits (Yellow Cables / Cable Trays) */}
                {selectedSystems.Electrical && (
                  <g filter="url(#glow-ele)">
                    {/* Cable Tray */}
                    <path
                      d="M 50,0 L 50,110 L 800,80 L 1000,80"
                      fill="none"
                      stroke="#eab308"
                      strokeWidth="18"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      opacity="0.45"
                    />
                    {/* Electric conduits running parallel */}
                    <path
                      d="M 45,0 L 45,105 L 800,75 M 55,0 L 55,115 L 800,85"
                      fill="none"
                      stroke="#facc15"
                      strokeWidth="3"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      opacity="0.75"
                    />
                  </g>
                )}
              </svg>
            </div>

            {/* AR Overlay HUD Graphics */}
            <div className="absolute top-4 left-4 flex items-center gap-2 bg-slate-900/80 border border-slate-700/80 rounded-lg px-3 py-1.5 text-[10px] font-mono text-slate-300">
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-ping"></span>
              <span>RA ALIGNEMENT : ACTIF (ACCURACY 4.2mm)</span>
            </div>

            {/* ---------------- HOTSPOTS & MARKERS ---------------- */}
            {/* 1. Technical Elements hotspots (only visible if AR is partially on and system is checked) */}
            {arOpacity > 15 &&
              PRESET_ELEMENTS.map((elem) => {
                if (!selectedSystems[elem.system]) return null;
                const isInspecting = inspectingElement?.id === elem.id;

                return (
                  <button
                    key={elem.id}
                    onClick={(e) => {
                      e.stopPropagation();
                      setInspectingElement(isInspecting ? null : elem);
                    }}
                    className="absolute group z-20"
                    style={{ left: `${elem.coordinates.x}%`, top: `${elem.coordinates.y}%` }}
                  >
                    {/* Pulsing ring */}
                    <span className="absolute -inset-2.5 rounded-full border border-white opacity-0 group-hover:opacity-100 group-hover:scale-110 transition-all duration-300 pointer-events-none"></span>
                    
                    <div
                      className={`w-6 h-6 rounded-full flex items-center justify-center border-2 border-white shadow-[0_0_12px_rgba(255,255,255,0.4)] transition-all ${
                        isInspecting
                          ? 'scale-125 bg-white text-slate-900'
                          : elem.status === 'Écart Détecté'
                          ? 'bg-amber-500 text-white'
                          : 'bg-blue-600 text-white hover:bg-blue-500'
                      }`}
                    >
                      {elem.status === 'Écart Détecté' ? (
                        <AlertTriangle className="w-3.5 h-3.5" />
                      ) : (
                        <Info className="w-3.5 h-3.5" />
                      )}
                    </div>

                    {/* Popover on hover/inspector */}
                    <div className="absolute left-1/2 bottom-8 -translate-x-1/2 bg-slate-900/95 border border-slate-700 p-2.5 rounded-xl text-[10px] text-white w-48 opacity-0 group-hover:opacity-100 transition-opacity duration-200 pointer-events-none shadow-xl z-50">
                      <div className="font-semibold truncate mb-0.5">{elem.name}</div>
                      <div className="text-slate-400 flex justify-between">
                        <span>Système :</span>
                        <span className="font-semibold text-blue-400">{elem.system}</span>
                      </div>
                      <div className="text-slate-400 flex justify-between">
                        <span>Haut. :</span>
                        <span>{elem.elevation}</span>
                      </div>
                      <div className="mt-1 flex items-center gap-1">
                        <span
                          className={`w-1.5 h-1.5 rounded-full ${
                            elem.status === 'Conforme' ? 'bg-emerald-500' : 'bg-amber-500'
                          }`}
                        ></span>
                        <span className={elem.status === 'Conforme' ? 'text-emerald-400' : 'text-amber-400'}>
                          {elem.status}
                        </span>
                      </div>
                    </div>
                  </button>
                );
              })}

            {/* 2. Registered Active Issues Markers */}
            {issues.map((issue) => {
              if (issue.coordinateX === undefined || issue.coordinateY === undefined) return null;
              if (!selectedSystems[issue.system]) return null;

              const isSelected = selectedIssueId === issue.id;

              return (
                <button
                  key={issue.id}
                  onClick={(e) => {
                    e.stopPropagation();
                    onSelectIssue(isSelected ? null : issue.id);
                  }}
                  className="absolute group z-30"
                  style={{ left: `${issue.coordinateX}%`, top: `${issue.coordinateY}%` }}
                >
                  <span className="absolute -inset-3 rounded-full border-2 border-red-500 animate-pulse pointer-events-none"></span>
                  <div
                    className={`w-7 h-7 rounded-full flex items-center justify-center border-2 border-red-500 text-white transition-all shadow-[0_0_15px_rgba(239,68,68,0.5)] ${
                      isSelected ? 'bg-red-500 scale-125' : 'bg-red-600/90 hover:bg-red-500'
                    }`}
                  >
                    <AlertTriangle className="w-4 h-4" />
                  </div>

                  {/* HUD Flag label */}
                  <div className="absolute left-8 top-1/2 -translate-y-1/2 bg-red-600/95 border border-red-400/30 px-2 py-1 rounded text-[10px] font-semibold whitespace-nowrap shadow-md text-white">
                    {issue.title}
                  </div>
                </button>
              );
            })}

            {/* Click/Prompt Overlay in Creation Mode */}
            {isAddingIssueMode && !clickCoordinates && (
              <div className="absolute inset-0 bg-red-500/5 backdrop-blur-[1px] flex items-center justify-center pointer-events-none z-10">
                <div className="bg-slate-900/95 border border-red-500/40 p-4 rounded-xl text-center shadow-2xl max-w-xs">
                  <AlertTriangle className="w-8 h-8 text-red-500 mx-auto mb-2 animate-bounce" />
                  <h4 className="font-semibold text-xs text-white uppercase tracking-wider mb-1">
                    Signaler un écart RA
                  </h4>
                  <p className="text-[10px] text-slate-300">
                    Cliquez sur la zone de chantier où vous observez une non-conformité par rapport au tracé fluorescent.
                  </p>
                </div>
              </div>
            )}

            {/* Discrepancy Placement Pin Indicator */}
            {clickCoordinates && (
              <div
                className="absolute z-40 transform -translate-x-1/2 -translate-y-1/2"
                style={{ left: `${clickCoordinates.x}%`, top: `${clickCoordinates.y}%` }}
              >
                <div className="w-8 h-8 rounded-full bg-amber-500 flex items-center justify-center border-2 border-white animate-bounce text-slate-900 shadow-xl">
                  <Plus className="w-5 h-5 font-bold" />
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Dynamic Detail Card Panels: Element Inspector or Custom Form */}
        <AnimatePresence mode="wait">
          {clickCoordinates && (
            <motion.div
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              className="bg-slate-900/90 border border-amber-500/40 p-5 rounded-2xl shadow-xl"
            >
              <div className="flex justify-between items-center mb-4">
                <h4 className="font-display font-bold text-sm text-amber-400 flex items-center gap-2">
                  <AlertTriangle className="w-4 h-4" />
                  Nouvel Écart détecté au point ({clickCoordinates.x}%, {clickCoordinates.y}%)
                </h4>
                <button onClick={cancelAddingIssue} className="text-slate-400 hover:text-white text-xs">
                  Annuler
                </button>
              </div>

              <form onSubmit={handleCreateIssueSubmit} className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="md:col-span-1">
                  <label className="block text-[10px] uppercase font-bold text-slate-400 mb-1">
                    Titre du problème *
                  </label>
                  <input
                    type="text"
                    required
                    value={newIssueTitle}
                    onChange={(e) => setNewIssueTitle(e.target.value)}
                    placeholder="ex: Collision gaine HVAC / Poutre"
                    className="w-full text-xs bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-white focus:outline-none focus:border-amber-500"
                  />
                </div>

                <div className="md:col-span-1">
                  <label className="block text-[10px] uppercase font-bold text-slate-400 mb-1">
                    Réseau Technique affecté
                  </label>
                  <select
                    value={newIssueSystem}
                    onChange={(e) => setNewIssueSystem(e.target.value as SystemType)}
                    className="w-full text-xs bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-white focus:outline-none focus:border-amber-500"
                  >
                    <option value="HVAC">HVAC / Ventilation</option>
                    <option value="Plumbing">Plomberie & Fluides</option>
                    <option value="Electrical">Électricité</option>
                    <option value="FireProtection">Sécurité Incendie</option>
                  </select>
                </div>

                <div className="md:col-span-1">
                  <label className="block text-[10px] uppercase font-bold text-slate-400 mb-1">
                    Niveau de Priorité
                  </label>
                  <select
                    value={newIssuePriority}
                    onChange={(e) => setNewIssuePriority(e.target.value as 'Haute' | 'Moyenne' | 'Basse')}
                    className="w-full text-xs bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-white focus:outline-none focus:border-amber-500"
                  >
                    <option value="Basse">Basse (Simple écart d'alignement)</option>
                    <option value="Moyenne">Moyenne (Entrave mineure)</option>
                    <option value="Haute">Haute (Blocage chantier/Clash)</option>
                  </select>
                </div>

                <div className="md:col-span-3">
                  <label className="block text-[10px] uppercase font-bold text-slate-400 mb-1">
                    Description détaillée de la non-conformité
                  </label>
                  <textarea
                    value={newIssueDesc}
                    onChange={(e) => setNewIssueDesc(e.target.value)}
                    placeholder="Décrivez précisément ce qui ne va pas (ex: le raccord de plomberie a été décalé de 15cm vers la gauche pour éviter un poteau non répertorié sur la maquette)."
                    className="w-full text-xs bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-white focus:outline-none focus:border-amber-500 h-16 resize-none"
                  ></textarea>
                </div>

                <div className="md:col-span-3 flex justify-end gap-2.5 mt-2">
                  <button
                    type="button"
                    onClick={cancelAddingIssue}
                    className="px-4 py-2 bg-slate-850 hover:bg-slate-800 text-xs font-semibold text-slate-300 rounded-lg"
                  >
                    Annuler
                  </button>
                  <button
                    type="submit"
                    className="px-4 py-2 bg-amber-500 hover:bg-amber-600 text-xs font-semibold text-slate-950 rounded-lg flex items-center gap-1"
                  >
                    <CheckCircle className="w-4 h-4" />
                    Enregistrer l'écart sur site
                  </button>
                </div>
              </form>
            </motion.div>
          )}

          {inspectingElement && !clickCoordinates && (
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="bg-slate-900 border border-slate-800 p-5 rounded-2xl flex flex-col md:flex-row gap-5 justify-between items-start"
            >
              <div className="flex-1">
                <div className="flex items-center gap-2 mb-2">
                  <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase border ${getSystemBg(inspectingElement.system)}`}>
                    {inspectingElement.system}
                  </span>
                  <span className="text-xs text-slate-400">ID Maquette: {inspectingElement.id}</span>
                </div>
                <h4 className="font-display font-bold text-base text-white mb-2">{inspectingElement.name}</h4>
                
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-4">
                  <div>
                    <span className="text-[10px] uppercase font-bold text-slate-500 block">Matériau</span>
                    <span className="text-xs text-slate-300">{inspectingElement.material}</span>
                  </div>
                  <div>
                    <span className="text-[10px] uppercase font-bold text-slate-500 block">Altitude/Niveau</span>
                    <span className="text-xs text-slate-300">{inspectingElement.elevation}</span>
                  </div>
                  {inspectingElement.diameter && (
                    <div>
                      <span className="text-[10px] uppercase font-bold text-slate-500 block">Dimension/Diamètre</span>
                      <span className="text-xs text-slate-300">{inspectingElement.diameter}</span>
                    </div>
                  )}
                  {inspectingElement.flowRate && (
                    <div>
                      <span className="text-[10px] uppercase font-bold text-slate-500 block">Débit nominal</span>
                      <span className="text-xs text-slate-300">{inspectingElement.flowRate}</span>
                    </div>
                  )}
                  {inspectingElement.voltage && (
                    <div>
                      <span className="text-[10px] uppercase font-bold text-slate-500 block">Tension réseau</span>
                      <span className="text-xs text-slate-300">{inspectingElement.voltage}</span>
                    </div>
                  )}
                </div>
              </div>

              <div className="flex flex-col gap-2 min-w-[200px] items-stretch self-stretch md:self-auto justify-center">
                <div className="p-3 bg-slate-950/60 rounded-xl border border-slate-800 text-center">
                  <span className="text-[10px] text-slate-500 block mb-1">STATUT DE CONFORMITÉ</span>
                  <div className="flex items-center justify-center gap-1.5">
                    <span className={`w-2 h-2 rounded-full ${inspectingElement.status === 'Conforme' ? 'bg-emerald-500' : 'bg-amber-500 animate-ping'}`}></span>
                    <span className={`text-xs font-bold ${inspectingElement.status === 'Conforme' ? 'text-emerald-400' : 'text-amber-400'}`}>
                      {inspectingElement.status === 'Conforme' ? 'CONFORME À LA MAQUETTE' : 'ÉCART CHANTIER DÉTECTÉ'}
                    </span>
                  </div>
                </div>
                {inspectingElement.status === 'Écart Détecté' && (
                  <button
                    onClick={() => {
                      setClickCoordinates(inspectingElement.coordinates);
                      setNewIssueTitle(`Écart d'alignement - ${inspectingElement.name}`);
                      setNewIssueSystem(inspectingElement.system);
                      setNewIssueDesc(`L'élément de plomberie ${inspectingElement.name} installé sur le chantier ne correspond pas aux coordonnées BIM théoriques (+2.85m). Détection d'un écart physique d'environ 12cm.`);
                    }}
                    className="w-full py-1.5 px-3 bg-amber-500 hover:bg-amber-600 text-slate-950 rounded-lg text-[11px] font-bold text-center"
                  >
                    Ouvrir la fiche d'écart
                  </button>
                )}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
